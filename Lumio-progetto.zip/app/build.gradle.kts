plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Numero di versione = numero della compilazione su GitHub (cresce a ogni aggiornamento)
val build = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1

android {
    namespace = "app.lumio.tv"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.lumio.tv"
        minSdk = 24
        targetSdk = 34
        versionCode = build
        versionName = "$build"
    }
    // Chiave di firma fissa: gli aggiornamenti si installano sopra la versione precedente
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.coil-kt:coil-compose:2.6.0")
    val m = "1.3.1"
    implementation("androidx.media3:media3-exoplayer:$m")
    implementation("androidx.media3:media3-exoplayer-hls:$m")
    implementation("androidx.media3:media3-exoplayer-dash:$m")
    implementation("androidx.media3:media3-ui:$m")
}
