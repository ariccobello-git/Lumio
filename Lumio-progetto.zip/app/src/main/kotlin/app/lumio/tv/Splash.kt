package app.lumio.tv

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val sand = Color(0xFFFFF2DE)
private val peach = Color(0xFFF6DDBE)
private val wood1 = Color(0xFFE6C7A0)
private val wood2 = Color(0xFFD2AC7E)
private val caramel = Color(0xFFC28A58)
private val cocoa = Color(0xFF6B4F3F)
private val ink = Color(0xFF4A352B)
private val cream = Color(0xFFF6E7CB)

private fun filmPath(): Path = Path().apply {
    moveTo(328f, 352f)
    cubicTo(336f, 400f, 360f, 440f, 420f, 456f)
    cubicTo(500f, 476f, 560f, 418f, 604f, 446f)
    cubicTo(652f, 482f, 560f, 506f, 520f, 482f)
    cubicTo(470f, 450f, 540f, 418f, 640f, 470f)
    cubicTo(740f, 522f, 810f, 430f, 782f, 470f)
    cubicTo(760f, 506f, 700f, 478f, 850f, 492f)
}

private fun DrawScope.reel(cx: Float, cy: Float, r: Float, deg: Float) {
    drawCircle(cocoa, r, Offset(cx, cy))
    drawCircle(cream, r - 9f, Offset(cx, cy), style = Stroke(5f))
    rotate(deg, Offset(cx, cy)) {
        for (k in 0 until 4) {
            val a = k * Math.PI / 4
            val dx = (cos(a) * (r - 14f)).toFloat()
            val dy = (sin(a) * (r - 14f)).toFloat()
            drawLine(cream, Offset(cx - dx, cy - dy), Offset(cx + dx, cy + dy), 6f, StrokeCap.Round)
        }
    }
    drawCircle(cream, 9f, Offset(cx, cy))
}

/** Animazione iniziale: una cinepresa d'epoca, la pellicola si srotola e si accumula sul pavimento. */
@Composable
fun Splash(onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        t.animateTo(1f, tween(3200, easing = LinearEasing))
        onDone()
    }
    val path = remember { filmPath() }
    val pm = remember { PathMeasure().also { it.setPath(path, false) } }
    val len = remember { pm.length }
    val seg = remember { Path() }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.verticalGradient(listOf(sand, peach), 0f, size.height * 0.75f))
            val s = min(size.width / 960f, size.height / 540f)
            val ox = (size.width - 960f * s) / 2f
            val oy = (size.height - 540f * s) / 2f
            val p = t.value
            val q = (1f - (1f - (p / 0.9f).coerceIn(0f, 1f)).let { it * it * it })
            withTransform({
                translate(ox, oy)
                scale(s, s, Offset.Zero)
            }) {
                // luce morbida e pavimento in legno
                drawCircle(Color(0x55FFE8C2), 260f, Offset(300f, 230f))
                drawRect(Brush.verticalGradient(listOf(wood1, wood2), 400f, 540f), Offset(-200f, 400f), Size(1400f, 200f))
                for (k in 0 until 6) {
                    drawLine(Color(0x22A07850), Offset(-200f, 420f + k * 24f), Offset(1200f, 420f + k * 24f), 2f)
                }
                // treppiede
                val leg = Color(0xFF8A6446)
                drawLine(leg, Offset(205f, 360f), Offset(135f, 490f), 10f, StrokeCap.Round)
                drawLine(leg, Offset(300f, 360f), Offset(372f, 490f), 10f, StrokeCap.Round)
                drawLine(leg, Offset(252f, 360f), Offset(252f, 500f), 10f, StrokeCap.Round)
                // pellicola sul pavimento
                seg.reset()
                pm.getSegment(0f, len * q, seg, true)
                drawPath(seg, ink, style = Stroke(22f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(seg, cream, style = Stroke(14f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 11f))))
                // caricatori e corpo della cinepresa
                val deg = p * 900f
                reel(205f, 178f, 62f, deg)
                reel(312f, 166f, 50f, -deg * 1.2f)
                drawRoundRect(caramel, Offset(150f, 230f), Size(250f, 135f), CornerRadius(18f, 18f))
                drawRoundRect(Color(0x33FFFFFF), Offset(158f, 236f), Size(234f, 18f), CornerRadius(9f, 9f))
                drawRoundRect(Color(0xFF7A4F30), Offset(400f, 275f), Size(62f, 46f), CornerRadius(8f, 8f))
                drawCircle(ink, 26f, Offset(464f, 298f))
                drawCircle(cream, 15f, Offset(464f, 298f), style = Stroke(4f))
                drawRoundRect(ink, Offset(318f, 350f), Size(22f, 12f), CornerRadius(4f, 4f))
                // pellicola che esce dal caricatore
                drawLine(ink, Offset(255f, 232f), Offset(322f, 214f), 6f, StrokeCap.Round)
            }
        }
        Column(Modifier.align(Alignment.TopCenter).padding(top = 28.dp).alpha(((p01(t.value) - 0.2f) / 0.3f).coerceIn(0f, 1f))) {
            Text("Lumio", color = Color(0xFF6B4A33), fontSize = 46.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

private fun p01(v: Float) = v
