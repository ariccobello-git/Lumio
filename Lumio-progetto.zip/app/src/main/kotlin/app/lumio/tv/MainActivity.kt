package app.lumio.tv

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Th.apply(Store.theme, Store.customBg)
        setContent { Root() }
    }

    override fun onResume() {
        super.onResume()
        Flags.resume.intValue = Flags.resume.intValue + 1
    }
}

/* ---------- percorsi di navigazione (ogni "Indietro" torna di un livello) ---------- */
sealed class Route
class BrowseR(val list: ListInfo, val folder: Folder?, val crumbs: String) : Route()
class DetailR(val ch: Channel, val listId: String?) : Route()
class SetR(val page: String) : Route()
class EditR(val info: ListInfo?) : Route()
class Hit(val ch: Channel, val list: ListInfo)

private fun hhmm(ms: Long): String = SimpleDateFormat("HH:mm", Locale.ITALY).format(Date(ms))

private fun activityOf(c: Context): Activity? {
    var x: Context? = c
    while (x is ContextWrapper) {
        if (x is Activity) return x
        x = x.baseContext
    }
    return null
}

@Composable
fun Root() {
    var splash by remember { mutableStateOf(true) }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(Th.bg)) {
            if (splash) Splash { splash = false } else AppContent()
        }
    }
}

@Composable
fun AppContent() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val stack = remember { mutableStateListOf<Route>() }
    var lists by remember { mutableStateOf(Store.lists()) }
    var favs by remember { mutableStateOf(Store.favs()) }
    var prog by remember { mutableStateOf(Store.progress()) }
    var exit by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf<String?>(null) }

    fun reload() { lists = Store.lists(); favs = Store.favs(); prog = Store.progress() }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }

    // Al ritorno nell'app: aggiorna "continua a guardare" e, se avevo avviato la VPN, aggiorna le liste.
    val rs = Flags.resume.intValue
    LaunchedEffect(rs) {
        prog = Store.progress(); favs = Store.favs()
        if (Flags.vpnPending) {
            Flags.vpnPending = false
            busy = "Attendo la connessione della VPN…"
            delay(4000)
            busy = "Aggiorno le liste…"
            withContext(Dispatchers.IO) { Store.refreshAll(false) }
            busy = null
            lists = Store.lists()
        }
    }
    // Senza VPN collegata, le liste vecchie si aggiornano da sole all'avvio.
    LaunchedEffect(Unit) {
        if (Store.vpn == null) {
            withContext(Dispatchers.IO) { Store.refreshAll(true) }
            lists = Store.lists()
        }
    }

    fun play(ch: Channel, listId: String?, resume: Long) {
        val num = ch.chno ?: listId?.let { id -> Store.channels(id).indexOfFirst { it.url == ch.url } + 1 }?.takeIf { it > 0 } ?: 0
        ctx.startActivity(
            Intent(ctx, PlayerActivity::class.java)
                .putExtra("name", ch.name).putExtra("url", ch.url).putExtra("group", ch.group)
                .putExtra("logo", ch.logo).putExtra("kind", ch.kind.ordinal).putExtra("num", num)
                .putExtra("tvg", ch.tvgId).putExtra("resume", resume)
        )
    }

    BackHandler {
        when {
            stack.isNotEmpty() -> pop()
            tab != 0 -> tab = 0
            else -> exit = true
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (stack.isEmpty()) TopNav(tab) { tab = it }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (val r = stack.lastOrNull()) {
                null -> when (tab) {
                    0 -> HomeScreen(lists, prog, busy, Store.vpn != null, {
                        val p = Store.vpn
                        if (p == null) {
                            Toast.makeText(ctx, "Prima collega la tua VPN in Impostazioni", Toast.LENGTH_LONG).show()
                            tab = 4; stack.add(SetR("vpn"))
                        } else {
                            Flags.vpnPending = true
                            openApp(ctx, p)
                        }
                    }, { l ->
                        if (!l.ok && l.count == 0) Toast.makeText(ctx, "Lista non funzionante: " + l.msg, Toast.LENGTH_LONG).show()
                        else stack.add(BrowseR(l, null, l.name))
                    }, { p -> play(p.ch, null, p.pos) })
                    1 -> SearchScreen(lists) { stack.add(DetailR(it.ch, it.list.id)) }
                    2 -> FavScreen(favs) { stack.add(DetailR(it, null)) }
                    3 -> ManageScreen(lists, { reload() }, { stack.add(EditR(null)) }, { stack.add(EditR(it)) })
                    4 -> SettingsRoot { stack.add(SetR(it)) }
                    else -> GuideRoot { stack.add(SetR("guide:$it")) }
                }
                is BrowseR -> BrowseScreen(r, favs, { f -> stack.add(BrowseR(r.list, f, r.crumbs + " › " + f.title)) },
                    { c -> stack.add(DetailR(c, r.list.id)) }, { pop() })
                is DetailR -> DetailScreen(
                    r.ch, favs.any { it.url == r.ch.url }, Store.progOf(r.ch.url),
                    { pos -> play(r.ch, r.listId, pos) },
                    { Store.toggleFav(r.ch); favs = Store.favs() },
                    { Store.removeProgress(r.ch.url); prog = Store.progress(); pop() },
                    { pop() }
                )
                is SetR -> SettingsPage(r.page, { pop() }, { Th.apply(Store.theme, Store.customBg); reload() })
                is EditR -> EditScreen(r.info, { reload(); pop() }, { pop() })
            }
        }
    }

    if (exit) {
        Dialog3(
            onDismiss = { exit = false },
            onExit = { activityOf(ctx)?.finish() },
            onKill = {
                activityOf(ctx)?.finishAndRemoveTask()
                Handler(Looper.getMainLooper()).postDelayed({ Process.killProcess(Process.myPid()) }, 250)
            }
        )
    }
}

@Composable
fun Dialog3(onDismiss: () -> Unit, onExit: () -> Unit, onKill: () -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) { delay(60); runCatching { fr.requestFocus() } }
        Column(
            Modifier.width(520.dp).clip(RoundedCornerShape(16.dp)).background(Th.surface).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Vuoi uscire da Lumio?", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            TvButton("Resta nell'app", onDismiss, Modifier.fillMaxWidth().focusRequester(fr), w = null, primary = true)
            TvButton("Esci", onExit, Modifier.fillMaxWidth(), w = null)
            TvButton("Esci e arresta del tutto l'app", onKill, Modifier.fillMaxWidth(), w = null)
            Text(
                "«Arresta del tutto» chiude anche i processi rimasti in background.",
                color = Th.muted, fontSize = 13.sp
            )
        }
    }
}

/* ---------- barra e intestazioni ---------- */
@Composable
fun TopNav(tab: Int, onTab: (Int) -> Unit) {
    val names = listOf("Home", "Cerca", "Preferiti", "Liste", "Impostazioni", "Guida")
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("Lumio", color = Th.accent, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(end = 14.dp))
        names.forEachIndexed { i, n -> TvButton(n, { onTab(i) }, Modifier.weight(1f), w = null, h = 40.dp, selected = tab == i, size = 15f) }
    }
}

@Composable
fun Header(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TvButton("◀ Indietro", onBack, w = 130.dp, h = 40.dp, size = 15f)
        FitText(title, Color.White, 20f, Modifier.weight(1f), true, TextAlign.Start)
        trailing()
    }
}

private fun tileBrush(name: String): Brush {
    val h = (name.hashCode() and 0x7fffffff) % 360
    return Brush.linearGradient(listOf(Color.hsv(h.toFloat(), 0.45f, 0.5f), Color.hsv(((h + 50) % 360).toFloat(), 0.55f, 0.3f)))
}

@Composable
fun SectionTitle(t: String) {
    Text(t, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
}

/* ---------- HOME: liste in primo piano ---------- */
@Composable
fun HomeScreen(
    lists: List<ListInfo>, prog: List<Prog>, busy: String?, vpnSet: Boolean,
    onVpn: () -> Unit, onList: (ListInfo) -> Unit, onResume: (Prog) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 32.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Tv(onVpn, Modifier.fillMaxWidth().height(62.dp), RoundedCornerShape(16.dp), Th.accent) {
                FitText(
                    if (vpnSet) "🔒  Avvia la VPN e aggiorna le liste" else "🔒  Collega la tua VPN (Impostazioni)",
                    Color.White, 20f, Modifier.align(Alignment.Center).padding(horizontal = 16.dp), true
                )
            }
        }
        if (busy != null) item { Text(busy, color = Th.muted, fontSize = 14.sp) }
        if (prog.isNotEmpty()) {
            item { SectionTitle("Continua a guardare") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(4.dp)) {
                    items(prog) { p -> ProgCard(p) { onResume(p) } }
                }
            }
        }
        item { SectionTitle("Le tue liste") }
        if (lists.isEmpty()) item {
            Text("Nessuna lista. Apri «Liste» dalla barra in alto per aggiungerne una.", color = Th.muted, fontSize = 16.sp)
        }
        items(lists.chunked(3)) { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { l -> ListCard(l, Modifier.weight(1f)) { onList(l) } }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun ListCard(l: ListInfo, modifier: Modifier, onClick: () -> Unit) {
    Tv(onClick, modifier.height(112.dp), RoundedCornerShape(16.dp), Th.surface) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Th.violet.copy(alpha = 0.5f), Th.surface))))
        Column(Modifier.align(Alignment.BottomStart).padding(14.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Dot(l.ok)
                FitText(l.name, Color.White, 20f, Modifier.weight(1f), true, TextAlign.Start)
            }
            Text(
                if (l.ok) "${l.count} contenuti" else l.msg,
                color = if (l.ok) Th.muted else Th.bad, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ProgCard(p: Prog, onClick: () -> Unit) {
    Tv(onClick, Modifier.size(210.dp, 118.dp), RoundedCornerShape(12.dp), Th.surface) {
        Box(Modifier.fillMaxSize().background(tileBrush(p.ch.name)))
        FitText(p.ch.name, Color.White, 15f, Modifier.align(Alignment.Center).padding(horizontal = 10.dp), true)
        Text("Riprendi da " + clock(p.pos), color = Color.White, fontSize = 12.sp, modifier = Modifier.align(Alignment.BottomStart).padding(8.dp, 0.dp, 8.dp, 10.dp))
        Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(5.dp).background(Color(0x66000000))) {
            Box(Modifier.fillMaxWidth((p.pos.toFloat() / p.dur.toFloat()).coerceIn(0.02f, 1f)).fillMaxHeight().background(Th.accent))
        }
    }
}

/* ---------- ESPLORA a livelli ---------- */
@Composable
fun FolderTile(f: Folder, onClick: () -> Unit) {
    Tv(onClick, Modifier.fillMaxWidth().height(96.dp), RoundedCornerShape(14.dp), Th.surface) {
        Box(Modifier.fillMaxSize().background(tileBrush(f.title)))
        Column(Modifier.align(Alignment.CenterStart).padding(14.dp).fillMaxWidth()) {
            FitText(f.title, Color.White, 18f, Modifier.fillMaxWidth(), true, TextAlign.Start)
            Text("${f.count} contenuti  ›", color = Color(0xFFE6E8FF), fontSize = 13.sp)
        }
    }
}

@Composable
fun ChannelTile(c: Channel, fav: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Tv(onClick, Modifier.fillMaxWidth().height(96.dp), RoundedCornerShape(12.dp), Th.surface) {
        Box(Modifier.fillMaxSize().background(tileBrush(c.name)))
        if (c.logo != null) {
            val req = remember(c.logo) { ImageRequest.Builder(ctx).data(c.logo).size(200, 110).crossfade(false).build() }
            AsyncImage(
                model = req, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.align(Alignment.Center).fillMaxSize().padding(10.dp, 8.dp, 10.dp, 28.dp)
            )
        }
        FitText(
            c.name, Color.White, 13f,
            Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color(0x99000000)).padding(8.dp, 5.dp), false, TextAlign.Start
        )
        if (fav) Text("♥", color = Th.accent, fontSize = 16.sp, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
    }
}

@Composable
fun BrowseScreen(r: BrowseR, favs: List<Channel>, onFolder: (Folder) -> Unit, onLeaf: (Channel) -> Unit, onBack: () -> Unit) {
    var sort by remember { mutableStateOf(Sort.values()[Store.sortMode.coerceIn(0, Sort.values().size - 1)]) }
    var menu by remember { mutableStateOf(false) }
    val sortable = r.folder?.sortable ?: true
    val shown by produceState<List<Node>?>(null, r, sort) {
        value = withContext(Dispatchers.IO) {
            val n = r.folder?.let { it.kids() } ?: Store.root(r.list)
            if (sortable) sortNodes(n, sort) else n
        }
    }
    val favUrls = remember(favs) { favs.map { it.url }.toHashSet() }
    val list = shown
    Column(Modifier.fillMaxSize()) {
        Header(r.crumbs, onBack) {
            if (sortable && list != null && list.size > 1) TvButton("Ordina: " + sort.label, { menu = true }, w = 250.dp, h = 40.dp, size = 14f)
        }
        when {
            list == null -> Text("Caricamento…", color = Th.muted, fontSize = 16.sp, modifier = Modifier.padding(32.dp))
            list.isEmpty() -> Text("Nessun contenuto in questa sezione.", color = Th.muted, fontSize = 16.sp, modifier = Modifier.padding(32.dp))
            else -> LazyVerticalGrid(
                GridCells.Adaptive(190.dp), Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 32.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list) { n ->
                    when (n) {
                        is Folder -> FolderTile(n) { onFolder(n) }
                        is Leaf -> ChannelTile(n.ch, favUrls.contains(n.ch.url)) { onLeaf(n.ch) }
                    }
                }
            }
        }
    }
    if (menu) {
        val opts = Sort.values().filter { (it != Sort.NUM_UP && it != Sort.NUM_DOWN) || (list != null && hasNumbers(list)) }
        ChoiceDialog("Ordina per", opts.map { it.label }, opts.indexOf(sort), { i ->
            sort = opts[i]; Store.sortMode = sort.ordinal; menu = false
        }, { menu = false })
    }
}

/* ---------- SCHEDA del contenuto ---------- */
@Composable
fun DetailScreen(
    ch: Channel, fav: Boolean, prog: Prog?, onPlay: (Long) -> Unit, onFav: () -> Unit,
    onRemoveProg: () -> Unit, onBack: () -> Unit
) {
    var info by remember { mutableStateOf(false) }
    val epg by produceState(emptyList<Programme>(), ch.tvgId) {
        val id = ch.tvgId
        value = if (id == null) emptyList() else withContext(Dispatchers.IO) { Epg.query(id, System.currentTimeMillis(), 14) }
    }
    val now = System.currentTimeMillis()
    val cur = epg.firstOrNull { it.s <= now && it.e > now }
    val next = epg.firstOrNull { it.s > now }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Header(ch.name, onBack)
        Row(Modifier.padding(horizontal = 32.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Box(Modifier.size(300.dp, 170.dp).clip(RoundedCornerShape(14.dp)).background(tileBrush(ch.name))) {
                if (ch.logo != null) {
                    val req = remember(ch.logo) { ImageRequest.Builder(ctx).data(ch.logo).size(300, 170).crossfade(false).build() }
                    AsyncImage(req, null, Modifier.align(Alignment.Center).fillMaxSize().padding(24.dp), contentScale = ContentScale.Fit)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(ch.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    (when (ch.kind) { Kind.LIVE -> "Canale live"; Kind.MOVIE -> "Film"; Kind.SERIES -> "Serie TV" }) + "  ·  " + ch.group,
                    color = Th.muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (cur != null) Text("Ora in onda: " + hhmm(cur.s) + "–" + hhmm(cur.e) + "  " + cur.title, color = Color.White, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (next != null) Text("A seguire: " + hhmm(next.s) + "  " + next.title, color = Th.muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (prog != null) Text("Ti sei fermato a " + clock(prog.pos) + " su " + clock(prog.dur), color = Th.accent, fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.padding(horizontal = 32.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (prog != null) {
                TvButton("▶ Riprendi", { onPlay(prog.pos) }, Modifier.weight(1f), w = null, h = 48.dp, primary = true)
                TvButton("↺ Dall'inizio", { onPlay(0L) }, Modifier.weight(1f), w = null, h = 48.dp)
            } else {
                TvButton("▶ Guarda", { onPlay(0L) }, Modifier.weight(1f), w = null, h = 48.dp, primary = true)
            }
            TvButton(if (fav) "♥ Nei preferiti" else "♡ Preferito", onFav, Modifier.weight(1f), w = null, h = 48.dp)
            if (epg.isNotEmpty()) TvButton("ℹ Info guida", { info = true }, Modifier.weight(1f), w = null, h = 48.dp)
            if (prog != null) TvButton("✕ Togli da Continua", onRemoveProg, Modifier.weight(1f), w = null, h = 48.dp)
        }
    }
    if (info) LinesDialog("Guida programmi · " + ch.name, epg.map { Triple(hhmm(it.s) + "–" + hhmm(it.e), it.title, it.desc) }) { info = false }
}

/* ---------- CERCA e PREFERITI: solo elenco di nomi ---------- */
@Composable
fun NameRow(title: String, sub: String, onClick: () -> Unit) {
    Tv(onClick, Modifier.fillMaxWidth().height(58.dp), RoundedCornerShape(10.dp), Th.surface) {
        Column(Modifier.align(Alignment.CenterStart).padding(horizontal = 16.dp).fillMaxWidth()) {
            FitText(title, Color.White, 18f, Modifier.fillMaxWidth(), true, TextAlign.Start)
            Text(sub, color = Th.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun SearchScreen(lists: List<ListInfo>, onOpen: (Hit) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val res by produceState(emptyList<Hit>(), q, lists) {
        delay(250)
        val t = q.trim()
        value = if (t.length < 2) emptyList() else withContext(Dispatchers.IO) {
            val out = ArrayList<Hit>()
            for (l in lists) {
                for (c in Store.channels(l.id)) {
                    if (c.name.contains(t, true)) { out.add(Hit(c, l)); if (out.size >= 200) break }
                }
                if (out.size >= 200) break
            }
            out
        }
    }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) q = t
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            TvField("Cerca (premi OK per scrivere, anche con l'app Google TV)", q, { q = it }, Modifier.weight(1f), singleLine = true)
            TvButton("🎤 Detta", {
                try {
                    mic.launch(
                        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
                    )
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Dettatura non disponibile su questo dispositivo", Toast.LENGTH_LONG).show()
                }
            }, w = 140.dp, h = 56.dp, primary = true)
        }
        if (q.trim().length < 2) Text("Scrivi almeno 2 lettere. Il risultato è un elenco di nomi: scegline uno per aprire la scheda.", color = Th.muted, fontSize = 14.sp)
        else if (res.isEmpty()) Text("Nessun risultato.", color = Th.muted, fontSize = 16.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(res) { h -> NameRow(h.ch.name, h.list.name + "  ·  " + h.ch.group) { onOpen(h) } }
        }
    }
}

@Composable
fun FavScreen(favs: List<Channel>, onOpen: (Channel) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 32.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("Preferiti")
        if (favs.isEmpty()) Text("Nessun preferito: aprendo un contenuto trovi il pulsante ♡ Preferito.", color = Th.muted, fontSize = 16.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(favs) { c -> NameRow(c.name, c.group) { onOpen(c) } }
        }
    }
}

/* ---------- GESTIONE LISTE (l'unico posto per aggiungere, modificare, eliminare) ---------- */
@Composable
fun ManageScreen(lists: List<ListInfo>, onChange: () -> Unit, onNew: () -> Unit, onEdit: (ListInfo) -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }
    var del by remember { mutableStateOf<ListInfo?>(null) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.ITALY) }
    fun run(l: ListInfo?) {
        scope.launch {
            busy = l?.id ?: "*"
            withContext(Dispatchers.IO) { if (l == null) Store.refreshAll(false) else Store.refresh(l) }
            busy = null
            onChange()
        }
    }
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 32.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TvButton("+ Nuova lista", onNew, Modifier.weight(1f), w = null, h = 48.dp, primary = true)
                TvButton(if (busy == "*") "Aggiorno…" else "↻ Aggiorna tutte", { if (busy == null) run(null) }, Modifier.weight(1f), w = null, h = 48.dp)
            }
        }
        if (lists.isEmpty()) item { Text("Nessuna lista caricata.", color = Th.muted, fontSize = 16.sp) }
        items(lists, key = { it.id }) { l ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Th.surface).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Dot(l.ok)
                    Text(l.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(l.url, color = Th.muted, fontSize = 12.sp)
                Text(
                    if (l.ok) "Funzionante · ${l.count} contenuti · aggiornata il ${fmt.format(Date(l.updated))}" else "Non funziona: " + l.msg,
                    color = if (l.ok) Th.ok else Th.bad, fontSize = 14.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TvButton("Modifica", { onEdit(l) }, Modifier.weight(1f), w = null, h = 42.dp)
                    TvButton(if (busy == l.id) "Verifico…" else "Verifica", { if (busy == null) run(l) }, Modifier.weight(1f), w = null, h = 42.dp)
                    TvButton("Elimina", { del = l }, Modifier.weight(1f), w = null, h = 42.dp)
                }
            }
        }
    }
    del?.let { d ->
        ConfirmDialog("Eliminare la lista?", "«" + d.name + "» verrà rimossa da Lumio.", "Elimina", {
            Store.removeList(d.id); del = null; onChange()
        }, { del = null })
    }
}

@Composable
fun EditScreen(info: ListInfo?, onDone: () -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(info?.name ?: "") }
    var url by remember { mutableStateOf(info?.url ?: "") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var good by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Header(if (info == null) "Nuova lista" else "Modifica lista", onBack)
        Column(Modifier.padding(horizontal = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            TvField("Nome della lista", name, { name = it; msg = null }, Modifier.fillMaxWidth(), singleLine = true)
            TvField("Indirizzo della lista (URL M3U) · il testo si vede per intero", url, { url = it; msg = null }, Modifier.fillMaxWidth())
            if (msg != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Dot(good)
                    Text(msg ?: "", color = if (good) Th.ok else Th.bad, fontSize = 15.sp, modifier = Modifier.weight(1f))
                }
            }
            Text("Premi OK sul campo per aprire la tastiera: puoi scrivere anche con l'app Google TV sul telefono.", color = Th.muted, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TvButton(if (busy) "Verifico la lista…" else "Salva", {
                    if (!busy) {
                        val u = url.trim()
                        if (!(u.startsWith("http://", true) || u.startsWith("https://", true))) {
                            good = false; msg = "L'indirizzo deve iniziare con http:// o https://"
                        } else if (Store.hasUrl(u, info?.id)) {
                            good = false; msg = "Questa lista è già presente: non verrà caricata."
                        } else {
                            busy = true; msg = null
                            scope.launch {
                                val r = withContext(Dispatchers.IO) {
                                    runCatching {
                                        if (info == null) Store.addList(name.trim().ifEmpty { "La mia lista" }, u)
                                        else Store.editList(info.id, name.trim().ifEmpty { info.name }, u)
                                    }
                                }
                                busy = false
                                val ok = r.getOrNull()
                                if (ok != null) {
                                    good = true; msg = "Lista funzionante: " + ok.count + " contenuti"
                                    delay(900); onDone()
                                } else {
                                    good = false
                                    val e = r.exceptionOrNull()
                                    msg = if (e is DuplicateException) "Questa lista è già presente: non verrà caricata." else friendlyError(e ?: Exception())
                                }
                            }
                        }
                    }
                }, Modifier.weight(1f), w = null, h = 48.dp, primary = true)
                TvButton("Annulla", onBack, Modifier.weight(1f), w = null, h = 48.dp)
            }
        }
    }
}

/* ---------- IMPOSTAZIONI (a livelli) ---------- */
@Composable
fun SettingsRoot(onOpen: (String) -> Unit) {
    val entries = listOf(
        Triple("vpn", "Scorciatoia VPN", "Collega l'app VPN che hai installato"),
        Triple("theme", "Colori e sfondo", "4 sfondi pronti e colori personalizzati"),
        Triple("subs", "Sottotitoli", "Dimensione e alto contrasto"),
        Triple("play", "Riproduzione e codec", "Decodifica, buffer, formato predefinito"),
        Triple("upd", "Aggiornamenti", "Versione, codec e versioni precedenti"),
        Triple("reset", "Ripristino", "Torna ai valori iniziali")
    )
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 32.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(entries) { (k, t, d) ->
            Tv({ onOpen(k) }, Modifier.fillMaxWidth().height(66.dp), RoundedCornerShape(12.dp), Th.surface) {
                Column(Modifier.align(Alignment.CenterStart).padding(horizontal = 18.dp)) {
                    Text(t, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(d, color = Th.muted, fontSize = 13.sp)
                }
                Text("›", color = Th.muted, fontSize = 26.sp, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp))
            }
        }
    }
}

@Composable
fun SettingRow(title: String, value: String, onClick: () -> Unit, swatch: Color? = null) {
    Tv(onClick, Modifier.fillMaxWidth().height(56.dp), RoundedCornerShape(12.dp), Th.surface) {
        Row(Modifier.align(Alignment.CenterStart).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (swatch != null) Box(Modifier.size(26.dp).clip(RoundedCornerShape(6.dp)).background(swatch))
            FitText(title, Color.White, 18f, Modifier.width(470.dp), true, TextAlign.Start)
            FitText(value, Th.muted, 15f, Modifier.width(300.dp), false, TextAlign.End)
        }
    }
}

fun loadApps(ctx: Context): List<Pair<String, String>> {
    val pm = ctx.packageManager
    val i1 = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val i2 = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
    return (pm.queryIntentActivities(i1, 0) + pm.queryIntentActivities(i2, 0))
        .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        .distinctBy { it.first }
        .filter { it.first != ctx.packageName }
        .sortedBy { it.second.lowercase() }
}

fun openApp(c: Context, p: String) {
    val pm = c.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(p) ?: pm.getLaunchIntentForPackage(p)
    if (i != null) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    } else {
        Toast.makeText(c, "App non trovata", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun SettingsPage(page: String, onBack: () -> Unit, onChanged: () -> Unit) {
    if (page.startsWith("guide:")) { GuidePage(page.removePrefix("guide:").toIntOrNull() ?: 0, onBack); return }
    val title = when (page) {
        "vpn" -> "Scorciatoia VPN"; "theme" -> "Colori e sfondo"; "subs" -> "Sottotitoli"
        "play" -> "Riproduzione e codec"; "upd" -> "Aggiornamenti"; else -> "Ripristino"
    }
    Column(Modifier.fillMaxSize()) {
        Header(title, onBack)
        Column(Modifier.padding(horizontal = 32.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (page) {
                "vpn" -> VpnPage()
                "theme" -> ThemePage(onChanged)
                "subs" -> SubsPage()
                "play" -> PlayPage()
                "upd" -> UpdPage()
                else -> ResetPage(onChanged)
            }
        }
    }
}

@Composable
fun VpnPage() {
    val ctx = LocalContext.current
    var pkg by remember { mutableStateOf(Store.vpn) }
    val apps = remember { loadApps(ctx) }
    val name = apps.firstOrNull { it.first == pkg }?.second
    var pick by remember { mutableStateOf(false) }
    Text(
        if (name != null) "App collegata: $name" else "Nessuna app collegata. Installa la tua VPN sulla stick, poi sceglila qui.",
        color = Color.White, fontSize = 17.sp
    )
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        TvButton("Scegli l'app VPN", { pick = true }, Modifier.weight(1f), w = null, h = 46.dp, primary = true)
        if (name != null) TvButton("Prova ad aprirla", { pkg?.let { openApp(ctx, it) } }, Modifier.weight(1f), w = null, h = 46.dp)
        if (name != null) TvButton("Scollega", { Store.vpn = null; pkg = null }, Modifier.weight(1f), w = null, h = 46.dp)
    }
    Text(
        "Dalla Home, il pulsante «Avvia la VPN» apre questa app; quando torni in Lumio le liste si aggiornano da sole. Lumio non contiene una VPN.",
        color = Th.muted, fontSize = 14.sp
    )
    if (pick) ChoiceDialog("Scegli l'app VPN", apps.map { it.second }, apps.indexOfFirst { it.first == pkg }, { i ->
        Store.vpn = apps[i].first; pkg = apps[i].first; pick = false
    }, { pick = false })
}

@Composable
fun ThemePage(onChanged: () -> Unit) {
    var cur by remember { mutableIntStateOf(Store.theme) }
    var cust by remember { mutableStateOf(Store.customBg) }
    var dlg by remember { mutableStateOf(false) }
    Text("Sfondi pronti", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(Th.presets.size) { i ->
            val p = Th.presets[i]
            SettingRow(p.name, if (cur == i && cust == 0L) "✓ in uso" else "", {
                Store.theme = i; Store.customBg = 0L; cur = i; cust = 0L; Th.apply(i, 0L); onChanged()
            }, Color(p.bg))
        }
        item {
            SettingRow("Colore di sfondo personalizzato", if (cust != 0L) "✓ in uso" else "", { dlg = true }, if (cust != 0L) Color(cust) else null)
        }
    }
    if (dlg) {
        val sel = Th.swatches.indexOfFirst { it.second == cust }
        ChoiceDialog("Colore di sfondo", Th.swatches.map { it.first }, sel, { i ->
            cust = Th.swatches[i].second; Store.customBg = cust; Th.apply(Store.theme, cust); dlg = false; onChanged()
        }, { dlg = false })
    }
}

@Composable
fun SubsPage() {
    var size by remember { mutableIntStateOf(Store.subSize) }
    var hc by remember { mutableStateOf(Store.subHc) }
    var dlg by remember { mutableStateOf(false) }
    val sizes = listOf("Normale", "Un po' più grandi", "Molto grandi")
    SettingRow("Dimensione dei sottotitoli", sizes[size], { dlg = true })
    SettingRow("Colori ad alto contrasto", if (hc) "Attivi (giallo su nero)" else "Spenti", { hc = !hc; Store.subHc = hc })
    SettingRow("Lingua predefinita audio e sottotitoli", "Italiano", {})
    Box(Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFF3B4A6B), Color(0xFF7A5C4A))))) {
        Text(
            "Così appariranno i sottotitoli",
            color = if (hc) Color(0xFFFFEB3B) else Color.White,
            fontSize = (20f * (1f + 0.25f * size)).sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp)
                .background(if (hc) Color.Black else Color(0x66000000)).padding(horizontal = 10.dp, vertical = 3.dp)
        )
    }
    if (dlg) ChoiceDialog("Dimensione dei sottotitoli", sizes, size, { i -> size = i; Store.subSize = i; dlg = false }, { dlg = false })
}

@Composable
fun PlayPage() {
    var dec by remember { mutableIntStateOf(Store.decoder) }
    var buf by remember { mutableIntStateOf(Store.buffer) }
    var asp by remember { mutableIntStateOf(Store.aspect) }
    var dlg by remember { mutableStateOf(0) }
    val decs = listOf("Automatica (consigliata)", "Preferisci software", "Preferisci hardware")
    val bufs = listOf("Automatico", "Normale", "Ampio (connessioni instabili)")
    SettingRow("Decodifica video", decs[dec], { dlg = 1 })
    SettingRow("Buffer", bufs[buf], { dlg = 2 })
    SettingRow("Formato immagine predefinito", ASPECTS[asp.coerceIn(0, ASPECTS.lastIndex)].name, { dlg = 3 })
    SettingRow("Riconnessione automatica", "Sempre attiva", {})
    Text(
        "Se un contenuto non parte per colpa del codec, Lumio prova da solo la decodifica software. Il buffer «Automatico» si allarga da solo se nota rallentamenti.",
        color = Th.muted, fontSize = 13.sp
    )
    when (dlg) {
        1 -> ChoiceDialog("Decodifica video", decs, dec, { i -> dec = i; Store.decoder = i; dlg = 0 }, { dlg = 0 })
        2 -> ChoiceDialog("Buffer", bufs, buf, { i -> buf = i; Store.buffer = i; dlg = 0 }, { dlg = 0 })
        3 -> ChoiceDialog("Formato immagine predefinito", ASPECTS.map { it.name }, asp, { i -> asp = i; Store.aspect = i; dlg = 0 }, { dlg = 0 })
    }
}

@Composable
fun UpdPage() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var repo by remember { mutableStateOf(Store.repo) }
    var rels by remember { mutableStateOf<List<Rel>>(emptyList()) }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val mine = remember { Store.appVersion(ctx) }
    Text("Versione installata: $mine", color = Color.White, fontSize = 17.sp)
    Text(
        "Codec: Media3 ExoPlayer 1.3.1 è incluso nell'app. Per aggiornarlo si installa una nuova versione di Lumio; per tornare indietro si reinstalla una versione precedente.",
        color = Th.muted, fontSize = 13.sp
    )
    TvField("Repository GitHub (utente/lumio)", repo, { repo = it; Store.repo = it }, Modifier.fillMaxWidth(), singleLine = true)
    TvButton(if (busy) "Controllo…" else "Verifica aggiornamenti", {
        if (!busy && repo.contains('/')) {
            busy = true; msg = null
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { Store.releases(repo.trim()) } }
                busy = false
                val l = r.getOrNull()
                if (l == null) msg = "Controllo non riuscito: " + friendlyError(r.exceptionOrNull() ?: Exception())
                else {
                    rels = l
                    val top = l.firstOrNull()?.tag?.filter { it.isDigit() }?.toIntOrNull() ?: 0
                    msg = if (top > mine) "Disponibile la versione $top" else "Sei aggiornato"
                }
            }
        } else if (!repo.contains('/')) msg = "Scrivi il repository nel formato utente/lumio"
    }, w = 260.dp, h = 46.dp, primary = true)
    if (msg != null) Text(msg ?: "", color = Th.accent, fontSize = 15.sp)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(rels) { r ->
            val n = r.tag.filter { it.isDigit() }.toIntOrNull() ?: 0
            SettingRow(
                "Versione $n  ·  " + r.date, if (n == mine) "installata" else if (r.apk != null) "scarica" else "",
                {
                    val u = r.apk
                    if (u != null) {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
                        catch (e: Exception) {
                            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("apk", u))
                            Toast.makeText(ctx, "Indirizzo copiato: aprilo con Downloader", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun ResetPage(onChanged: () -> Unit) {
    var dlg by remember { mutableStateOf(0) }
    Text("Il ripristino non si può annullare.", color = Th.muted, fontSize = 15.sp)
    SettingRow("Ripristina le impostazioni", "tema, sottotitoli, VPN, preferiti…", { dlg = 1 })
    SettingRow("Cancella tutto", "anche le liste", { dlg = 2 })
    if (dlg == 1) ConfirmDialog(
        "Ripristinare le impostazioni?",
        "Torna tutto ai valori iniziali: colori, sottotitoli, VPN collegata, preferiti, ordinamento e «Continua a guardare». Le liste restano.",
        "Ripristina", { Store.resetSettings(); Th.apply(0, 0L); dlg = 0; onChanged() }, { dlg = 0 }
    )
    if (dlg == 2) ConfirmDialog(
        "Cancellare tutto?",
        "Vengono rimosse anche le liste caricate e la guida programmi. Lumio torna come appena installata.",
        "Cancella tutto", { Store.resetAll(); Th.apply(0, 0L); dlg = 0; onChanged() }, { dlg = 0 }
    )
}

/* ---------- GUIDA ---------- */
private val GUIDE = listOf(
    "Come iniziare" to "1. Apri «Liste» dalla barra in alto e scegli «+ Nuova lista».\n2. Premi OK sul campo indirizzo: si apre la tastiera di sistema (puoi scrivere anche con l'app Google TV sul telefono).\n3. Premi «Salva»: se compare il pallino verde la lista funziona, se è rosso leggi il motivo.\n4. Torna in Home: la lista è tra «Le tue liste».\nUna lista con lo stesso indirizzo non viene mai caricata due volte.",
    "Navigare a livelli" to "Home → lista → sezione (Live TV, Film, Serie TV) → categoria → eventuale lettera → scheda del contenuto → riproduzione.\nLe serie si aprono in Serie → Stagioni → Episodi.\nIl tasto Indietro del telecomando torna sempre di un livello. Con «Ordina» scegli A-Z, Z-A, ultimi inseriti o numero (se la lista ha i numeri, che restano nascosti).",
    "Scheda e Continua a guardare" to "La scheda mostra titolo, categoria e, per i canali live, «Ora in onda» e «A seguire» se la lista ha la guida EPG. Il pulsante «Info guida» mostra il palinsesto: scorri con le frecce.\nSe interrompi un film o un episodio, lo ritrovi in Home sotto «Continua a guardare», con la barra di avanzamento.",
    "Cerca e Preferiti" to "In «Cerca» premi OK sul campo per scrivere, oppure usa «Detta» per la voce (serve il riconoscimento vocale di Google sulla stick). I risultati sono solo nomi: scegli un nome per aprire la scheda.\nI Preferiti si aggiungono dalla scheda con ♡.",
    "Il player" to "OK mostra i comandi; sinistra e destra senza comandi saltano di 10 secondi. In basso: Info (mette in pausa e mostra la guida), indietro/avanti 10 s, pausa/play; a destra Sottotitoli, Audio, Aspetto (anche formati IMAX e cinema), Velocità, Qualità.\nPer 7 secondi all'avvio compare il banner con numero, nome e titolo. Indietro chiude prima i menu, poi i comandi, poi il player. I tasti multimediali del telecomando funzionano.",
    "VPN" to "In Impostazioni → Scorciatoia VPN scegli l'app VPN che hai installato. Dalla Home il pulsante in alto la apre; al ritorno in Lumio le liste si aggiornano. Lumio non contiene una VPN.",
    "Se un contenuto non parte" to "Lumio riprova da solo a riconnettersi e, se il problema è il codec, passa alla decodifica software. In Impostazioni → Riproduzione puoi forzare decodifica e buffer. Controlla anche il pallino della lista in «Liste»: rosso significa lista non raggiungibile o scaduta.",
    "Colori, sottotitoli, ripristino" to "Impostazioni → Colori e sfondo: 4 sfondi pronti e 8 colori. Sottotitoli: dimensione e alto contrasto. Ripristino: riporta tutto ai valori iniziali.",
    "Aggiornamenti e codec" to "I codec fanno parte dell'app. In Impostazioni → Aggiornamenti scrivi il repository GitHub (utente/lumio) e verifica le nuove versioni; l'elenco permette di scaricare anche una versione precedente (prima disinstalla Lumio: Android non consente il ritorno a una versione più vecchia sopra a quella nuova)."
)

@Composable
fun GuideRoot(onOpen: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 32.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(GUIDE.size) { i ->
            Tv({ onOpen(i) }, Modifier.fillMaxWidth().height(56.dp), RoundedCornerShape(12.dp), Th.surface) {
                FitText(GUIDE[i].first, Color.White, 19f, Modifier.align(Alignment.CenterStart).padding(horizontal = 18.dp).fillMaxWidth(), true, TextAlign.Start)
            }
        }
    }
}

@Composable
fun GuidePage(i: Int, onBack: () -> Unit) {
    val g = GUIDE[i.coerceIn(0, GUIDE.lastIndex)]
    Column(Modifier.fillMaxSize()) {
        Header(g.first, onBack)
        LazyColumn(contentPadding = PaddingValues(horizontal = 32.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(g.second.split("\n")) { p ->
                Tv({}, Modifier.fillMaxWidth(), RoundedCornerShape(10.dp), Th.surface) {
                    Text(p, color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(14.dp))
                }
            }
        }
    }
}
