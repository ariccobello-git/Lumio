package app.lumio.tv

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var lists by remember { mutableStateOf(Store.lists()) }
    var sel by remember { mutableStateOf<String?>(null) }
    var favs by remember { mutableStateOf(Store.favs()) }
    var adding by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Channel?>(null) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            Store.lists().filter { System.currentTimeMillis() - it.updated > 12 * 3600_000L }
                .forEach { runCatching { Store.refresh(it) } }
        }
        lists = Store.lists()
    }

    fun play(c: Channel) {
        detail = null
        ctx.startActivity(
            Intent(ctx, PlayerActivity::class.java)
                .putExtra("name", c.name).putExtra("url", c.url)
                .putExtra("group", c.group).putExtra("logo", c.logo)
        )
    }
    fun toggleFav(c: Channel) {
        Store.toggleFav(c)
        favs = Store.favs()
    }

    BackHandler(tab != 0 && !adding) { tab = 0 }
    BackHandler(adding) { adding = false }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(Modifier.fillMaxSize().background(BG)) {
            if (!adding) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Lumio", color = Accent, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(end = 20.dp))
                    listOf("Home", "Cerca", "Preferiti", "Liste", "Impostazioni").forEachIndexed { i, t ->
                        TvButton(t, { tab = i }, selected = tab == i)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (adding) {
                    AddScreen { adding = false; lists = Store.lists(); tab = 0 }
                } else when (tab) {
                    0 -> HomeScreen(lists, sel, { sel = it }, favs, { detail = it }, { adding = true })
                    1 -> SearchScreen(lists, { detail = it })
                    2 -> FavScreen(favs) { detail = it }
                    3 -> ListsScreen(lists, { lists = Store.lists() }, { adding = true })
                    else -> SettingsScreen()
                }
            }
        }
        detail?.let { c ->
            Detail(c, favs.any { it.url == c.url }, { play(c) }, { toggleFav(c) }, { detail = null })
        }
    }
}

@Composable
fun Empty(t: String, s: String, label: String? = null, onClick: (() -> Unit)? = null) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(t, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(s, color = Muted, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
        if (label != null && onClick != null) TvButton(label, onClick, primary = true)
    }
}

@Composable
fun ChannelCard(c: Channel, fav: Boolean, onOpen: (Channel) -> Unit, modifier: Modifier = Modifier.size(190.dp, 110.dp)) {
    val h = (c.name.hashCode() and 0x7fffffff) % 360
    val c1 = Color.hsv(h.toFloat(), 0.55f, 0.55f)
    val c2 = Color.hsv(((h + 60) % 360).toFloat(), 0.65f, 0.35f)
    Tv({ onOpen(c) }, modifier, bg = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(c1, c2))))
        if (c.logo != null) {
            AsyncImage(
                model = c.logo, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.align(Alignment.Center).fillMaxSize().padding(14.dp, 14.dp, 14.dp, 34.dp)
            )
        }
        Text(
            c.name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color(0x99000000)).padding(8.dp, 4.dp)
        )
        if (fav) Text("♥", color = Accent, fontSize = 18.sp, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
    }
}

@Composable
fun RowOf(title: String, cs: List<Channel>, favs: List<Channel>, onOpen: (Channel) -> Unit) {
    Column {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 6.dp, horizontal = 4.dp)) {
            items(cs) { c -> ChannelCard(c, favs.any { it.url == c.url }, onOpen) }
        }
    }
}

@Composable
fun HomeScreen(
    lists: List<ListInfo>, sel: String?, onSel: (String) -> Unit,
    favs: List<Channel>, onOpen: (Channel) -> Unit, onAdd: () -> Unit
) {
    if (lists.isEmpty()) {
        Empty("Benvenuto su Lumio", "Aggiungi il link della tua lista M3U per iniziare", "+ Aggiungi lista", onAdd)
        return
    }
    val info = lists.firstOrNull { it.id == sel } ?: lists.first()
    val chans by produceState(emptyList<Channel>(), info.id, info.updated) {
        value = withContext(Dispatchers.IO) { Store.channels(info.id) }
    }
    val groups = remember(chans) { chans.groupBy { it.group }.toList() }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 40.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Box(
                Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(Violet, Accent))).padding(28.dp)
            ) {
                Column(Modifier.align(Alignment.BottomStart), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(info.name, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                    Text("${chans.size} canali in ${groups.size} categorie", color = Color(0xFFDFE0FF), fontSize = 15.sp)
                    val first = chans.firstOrNull()
                    if (first != null) TvButton("▶ Guarda ${first.name}", { onOpen(first) }, bg = BG)
                }
            }
        }
        if (lists.size > 1) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(4.dp)) {
                    items(lists) { l -> TvButton(l.name, { onSel(l.id) }, selected = l.id == info.id) }
                }
            }
        }
        if (favs.isNotEmpty()) item { RowOf("I miei preferiti", favs, favs, onOpen) }
        items(groups) { (g, cs) -> RowOf(g, cs, favs, onOpen) }
    }
}

@Composable
fun SearchScreen(lists: List<ListInfo>, onOpen: (Channel) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf(TextFieldValue("")) }
    val micReq = remember { FocusRequester() }
    val all by produceState(emptyList<Channel>(), lists) {
        value = withContext(Dispatchers.IO) { lists.flatMap { Store.channels(it.id) } }
    }
    val favs = Store.favs()
    val res = remember(q.text, all) {
        val t = q.text.trim()
        if (t.isEmpty()) emptyList() else all.filter { it.name.contains(t, true) || it.group.contains(t, true) }.take(300)
    }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) q = TextFieldValue(t, TextRange(t.length))
    }
    Row(Modifier.fillMaxSize().padding(horizontal = 40.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
        Column(Modifier.width(514.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TvField("Cerca canali, film, serie", q, { q = it }, true, Modifier.weight(1f), singleLine = true)
                TvButton("🎤 Detta", {
                    try {
                        mic.launch(
                            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
                        )
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Dettatura non disponibile su questo dispositivo", Toast.LENGTH_LONG).show()
                    }
                }, Modifier.focusRequester(micReq), primary = true)
            }
            Keyboard(
                { q = q.ins(it) }, { q = q.del() }, { q = TextFieldValue("") },
                { q = q.mv(-1) }, { q = q.mv(1) }, { runCatching { micReq.requestFocus() } }
            )
        }
        Box(Modifier.weight(1f).fillMaxHeight()) {
            if (q.text.isBlank()) {
                Empty("Cerca", "Scrivi o detta il nome di un canale")
            } else if (res.isEmpty()) {
                Empty("Nessun risultato", "Prova con meno lettere")
            } else {
                LazyVerticalGrid(
                    GridCells.Adaptive(150.dp), Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(6.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(res) { c -> ChannelCard(c, favs.any { it.url == c.url }, onOpen, Modifier.fillMaxWidth().height(100.dp)) }
                }
            }
        }
    }
}

@Composable
fun FavScreen(favs: List<Channel>, onOpen: (Channel) -> Unit) {
    if (favs.isEmpty()) {
        Empty("Nessun preferito", "Apri un contenuto e scegli ♡ Preferito per ritrovarlo qui")
        return
    }
    LazyVerticalGrid(
        GridCells.Adaptive(190.dp), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 40.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(favs) { c -> ChannelCard(c, true, onOpen, Modifier.fillMaxWidth().height(110.dp)) }
    }
}

@Composable
fun ListsScreen(lists: List<ListInfo>, onChange: () -> Unit, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }
    var del by remember { mutableStateOf<String?>(null) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.ITALY) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 40.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { TvButton("+ Aggiungi lista", onAdd, primary = true) }
        items(lists) { l ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Surface).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text(l.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${l.count} canali · aggiornata il ${fmt.format(Date(l.updated))}", color = Muted, fontSize = 14.sp)
                }
                TvButton(if (busy == l.id) "Aggiorno…" else "Aggiorna", {
                    if (busy == null) scope.launch {
                        busy = l.id
                        val r = withContext(Dispatchers.IO) { runCatching { Store.refresh(l) } }
                        busy = null
                        onChange()
                        Toast.makeText(
                            ctx,
                            if (r.isSuccess) "Lista aggiornata" else "Errore: " + (r.exceptionOrNull()?.message ?: ""),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                })
                TvButton(if (del == l.id) "Confermi?" else "Elimina", {
                    if (del == l.id) { Store.remove(l.id); del = null; onChange() } else del = l.id
                })
            }
        }
    }
}

@Composable
fun AddScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(TextFieldValue("")) }
    var url by remember { mutableStateOf(TextFieldValue("")) }
    var field by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val saveReq = remember { FocusRequester() }
    fun cur() = if (field == 0) name else url
    fun put(v: TextFieldValue) { if (field == 0) name = v else url = v }
    Row(Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(28.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Nuova lista", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            TvField("Nome della lista", name, { name = it }, field == 0, singleLine = true, onActive = { field = 0 })
            TvField("Indirizzo della lista (URL M3U) - si vede tutto", url, { url = it }, field == 1, onActive = { field = 1 })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TvButton("https://", { url = url.ins("https://"); field = 1 })
                TvButton("http://", { url = url.ins("http://"); field = 1 })
                TvButton(".m3u", { url = url.ins(".m3u"); field = 1 })
                TvButton("Incolla", {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
                    if (t != null) { url = url.ins(t.trim()); field = 1 }
                })
            }
            err?.let { Text(it, color = Accent, fontSize = 14.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TvButton(if (busy) "Carico la lista…" else "Salva e carica", {
                    val u = url.text.trim()
                    if (!busy) {
                        if (!u.startsWith("http")) {
                            err = "L'indirizzo deve iniziare con http o https"
                        } else {
                            busy = true
                            err = null
                            scope.launch {
                                val r = withContext(Dispatchers.IO) {
                                    runCatching { Store.addList(name.text.trim().ifEmpty { "La mia lista" }, u) }
                                }
                                busy = false
                                if (r.isSuccess) onDone() else err = "Impossibile caricare la lista: " + (r.exceptionOrNull()?.message ?: "errore")
                            }
                        }
                    }
                }, Modifier.focusRequester(saveReq), primary = true)
                TvButton("Annulla", onDone)
            }
        }
        Keyboard(
            { put(cur().ins(it)) }, { put(cur().del()) }, { put(TextFieldValue("")) },
            { put(cur().mv(-1)) }, { put(cur().mv(1)) }, { runCatching { saveReq.requestFocus() } }
        )
    }
}

fun loadApps(ctx: Context): List<Pair<String, String>> {
    val pm = ctx.packageManager
    val i1 = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val i2 = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
    return (pm.queryIntentActivities(i1, 0) + pm.queryIntentActivities(i2, 0))
        .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        .distinctBy { it.first }
        .filter { it.first != ctx.packageName }
        .sortedBy { it.second.lowercase() }
}

fun openApp(c: Context, p: String) {
    val pm = c.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(p) ?: pm.getLaunchIntentForPackage(p)
    if (i != null) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    } else {
        Toast.makeText(c, "App non trovata", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var pkg by remember { mutableStateOf(Store.vpn()) }
    var pick by remember { mutableStateOf(false) }
    val apps = remember { loadApps(ctx) }
    val name = apps.firstOrNull { it.first == pkg }?.second
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 40.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Scorciatoia VPN", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item {
            Text(
                if (name != null) "App collegata: $name" else "Nessuna app collegata. Installa la tua VPN sulla stick, poi sceglila qui.",
                color = Muted, fontSize = 16.sp
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TvButton(if (name != null) "Apri $name" else "Scegli app VPN", {
                    val p = pkg
                    if (p != null && name != null) openApp(ctx, p) else pick = true
                }, primary = true)
                TvButton(if (pick) "Chiudi elenco" else "Cambia app", { pick = !pick })
            }
        }
        if (pick) {
            items(apps) { a -> TvButton(a.second, { Store.setVpn(a.first); pkg = a.first; pick = false }) }
        }
        item {
            Text(
                "Lumio non contiene una VPN: apre quella che hai installato tu.",
                color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}

@Composable
fun Detail(c: Channel, fav: Boolean, onPlay: () -> Unit, onFav: () -> Unit, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
        Column(
            Modifier.width(520.dp).clip(RoundedCornerShape(16.dp)).background(Surface).padding(28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(c.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(c.group, color = Muted, fontSize = 15.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TvButton("▶ Guarda", onPlay, Modifier.focusRequester(fr), primary = true)
                TvButton(if (fav) "♥ Rimuovi" else "♡ Preferito", onFav)
                TvButton("Chiudi", onClose)
            }
        }
    }
}
