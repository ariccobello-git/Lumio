package app.lumio.tv

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

data class Channel(val name: String, val url: String, val group: String, val logo: String?)
data class ListInfo(val id: String, val name: String, val url: String, val updated: Long, val count: Int)

object M3u {
    private val attr = Regex("""([\w-]+)="([^"]*)"""")

    fun parse(f: File): List<Channel> = f.useLines { parse(it) }

    fun parse(lines: Sequence<String>): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var group = "Altri"
        var logo: String? = null
        for (raw in lines) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#EXTINF")) {
                val a = attr.findAll(l).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                group = a["group-title"]?.takeIf { it.isNotBlank() } ?: "Altri"
                logo = a["tvg-logo"]?.takeIf { it.isNotBlank() }
                val after = if (l.contains(',')) l.substringAfterLast(',').trim() else ""
                name = after.ifEmpty { a["tvg-name"] ?: "Senza nome" }
            } else if (!l.startsWith("#")) {
                out.add(Channel(name ?: l, l, group, logo))
                name = null
                group = "Altri"
                logo = null
            }
        }
        return out
    }
}

object Store {
    private lateinit var sp: SharedPreferences
    private lateinit var dir: File
    private val cache = ConcurrentHashMap<String, List<Channel>>()

    fun init(c: Context) {
        sp = c.getSharedPreferences("lumio", Context.MODE_PRIVATE)
        dir = c.filesDir
    }

    fun lists(): List<ListInfo> {
        val a = JSONArray(sp.getString("lists", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            ListInfo(o.getString("id"), o.getString("name"), o.getString("url"), o.getLong("updated"), o.getInt("count"))
        }
    }

    private fun saveLists(l: List<ListInfo>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url).put("updated", it.updated).put("count", it.count))
        }
        sp.edit().putString("lists", a.toString()).apply()
    }

    fun channels(id: String): List<Channel> {
        cache[id]?.let { return it }
        val f = File(dir, "list_$id.m3u")
        val ch = if (f.exists()) M3u.parse(f) else emptyList()
        cache[id] = ch
        return ch
    }

    fun addList(name: String, url: String): ListInfo {
        val id = System.currentTimeMillis().toString()
        val info = fetch(ListInfo(id, name, url, 0L, 0))
        saveLists(lists() + info)
        return info
    }

    fun refresh(info: ListInfo) {
        val n = fetch(info)
        saveLists(lists().map { if (it.id == info.id) n else it })
    }

    fun remove(id: String) {
        saveLists(lists().filter { it.id != id })
        File(dir, "list_$id.m3u").delete()
        cache.remove(id)
    }

    private fun fetch(i: ListInfo): ListInfo {
        val tmp = File(dir, "list_${i.id}.tmp")
        download(i.url, tmp)
        val ch = M3u.parse(tmp)
        if (ch.isEmpty()) {
            tmp.delete()
            throw Exception("Nessun canale trovato in questa lista")
        }
        tmp.copyTo(File(dir, "list_${i.id}.m3u"), true)
        tmp.delete()
        cache[i.id] = ch
        return i.copy(updated = System.currentTimeMillis(), count = ch.size)
    }

    private fun download(u: String, out: File) {
        var cur = u
        for (n in 0 until 6) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = false
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc == null) throw Exception("Reindirizzamento non valido")
                cur = URL(URL(cur), loc).toString()
                continue
            }
            if (code != 200) {
                c.disconnect()
                throw Exception("Il server ha risposto $code")
            }
            c.inputStream.use { inp -> out.outputStream().use { o -> inp.copyTo(o) } }
            c.disconnect()
            return
        }
        throw Exception("Troppi reindirizzamenti")
    }

    fun favs(): List<Channel> {
        val a = JSONArray(sp.getString("favs", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Channel(o.getString("n"), o.getString("u"), o.optString("g", "Altri"), o.optString("l", "").ifEmpty { null })
        }
    }

    fun isFav(u: String): Boolean = favs().any { it.url == u }

    fun toggleFav(c: Channel) {
        val l = favs().toMutableList()
        if (l.any { it.url == c.url }) l.removeAll { it.url == c.url } else l.add(c)
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("n", it.name).put("u", it.url).put("g", it.group).put("l", it.logo ?: "")) }
        sp.edit().putString("favs", a.toString()).apply()
    }

    fun vpn(): String? = sp.getString("vpn", null)
    fun setVpn(p: String) { sp.edit().putString("vpn", p).apply() }
}
