package app.lumio.tv

import android.content.Context
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream

class DuplicateException : Exception("Lista già presente")

data class ListInfo(
    val id: String, val name: String, val url: String, val updated: Long, val count: Int,
    val ok: Boolean, val msg: String, val epg: String?
)
data class Prog(val ch: Channel, val pos: Long, val dur: Long, val time: Long)
data class Programme(val s: Long, val e: Long, val title: String, val desc: String)
data class Rel(val tag: String, val name: String, val date: String, val apk: String?)

object Flags {
    var vpnPending = false
    val resume = androidx.compose.runtime.mutableIntStateOf(0)
}

object Store {
    private lateinit var sp: SharedPreferences
    private lateinit var dir: File
    private lateinit var app: Context
    private val cache = ConcurrentHashMap<String, List<Channel>>()
    private val roots = ConcurrentHashMap<String, Pair<Long, List<Node>>>()
    private val lk = Any()

    fun init(c: Context) {
        if (::sp.isInitialized) return
        app = c.applicationContext
        sp = app.getSharedPreferences("lumio", Context.MODE_PRIVATE)
        dir = app.filesDir
        Epg.init(app)
    }

    /* ---------- impostazioni ---------- */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var customBg: Long
        get() = sp.getLong("cbg", 0L)
        set(v) { sp.edit().putLong("cbg", v).apply() }
    var subSize: Int
        get() = sp.getInt("subsize", 1)          // 0 normale, 1 un po' più grandi, 2 molto grandi
        set(v) { sp.edit().putInt("subsize", v).apply() }
    var subHc: Boolean
        get() = sp.getBoolean("subhc", false)
        set(v) { sp.edit().putBoolean("subhc", v).apply() }
    var sortMode: Int
        get() = sp.getInt("sort", 0)
        set(v) { sp.edit().putInt("sort", v).apply() }
    var aspect: Int
        get() = sp.getInt("aspect", 0)
        set(v) { sp.edit().putInt("aspect", v).apply() }
    var decoder: Int
        get() = sp.getInt("decoder", 0)          // 0 automatica, 1 software, 2 hardware
        set(v) { sp.edit().putInt("decoder", v).apply() }
    var buffer: Int
        get() = sp.getInt("buffer", 0)           // 0 automatico, 1 normale, 2 ampio
        set(v) { sp.edit().putInt("buffer", v).apply() }
    var vpn: String?
        get() = sp.getString("vpn", null)
        set(v) { sp.edit().putString("vpn", v).apply() }
    var repo: String
        get() = sp.getString("repo", "") ?: ""
        set(v) { sp.edit().putString("repo", v.trim()).apply() }

    fun resetSettings() {
        val keep = sp.getString("lists", "[]")
        sp.edit().clear().putString("lists", keep).apply()
    }

    fun resetAll() {
        lists().forEach { File(dir, "list_${it.id}.m3u").delete() }
        sp.edit().clear().apply()
        cache.clear(); roots.clear()
        Epg.clear()
    }

    /* ---------- liste ---------- */
    fun lists(): List<ListInfo> {
        val a = JSONArray(sp.getString("lists", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            ListInfo(
                o.getString("id"), o.getString("name"), o.getString("url"), o.getLong("updated"),
                o.getInt("count"), o.optBoolean("ok", true), o.optString("msg", ""),
                o.optString("epg", "").ifEmpty { null }
            )
        }
    }

    private fun saveLists(l: List<ListInfo>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)
                    .put("updated", it.updated).put("count", it.count).put("ok", it.ok)
                    .put("msg", it.msg).put("epg", it.epg ?: "")
            )
        }
        sp.edit().putString("lists", a.toString()).apply()
    }

    fun hasUrl(url: String, exceptId: String? = null): Boolean {
        val n = normalizeUrl(url)
        return lists().any { it.id != exceptId && normalizeUrl(it.url) == n }
    }

    fun channels(id: String): List<Channel> {
        cache[id]?.let { return it }
        val f = File(dir, "list_$id.m3u")
        val ch = if (f.exists()) f.useLines { M3u.parse(it) } else emptyList()
        cache[id] = ch
        return ch
    }

    fun root(info: ListInfo): List<Node> {
        roots[info.id]?.let { if (it.first == info.updated) return it.second }
        val r = buildRoot(channels(info.id))
        roots[info.id] = info.updated to r
        return r
    }

    fun addList(name: String, url: String): ListInfo {
        if (hasUrl(url)) throw DuplicateException()
        val info = fetch(ListInfo(System.currentTimeMillis().toString(), name, url.trim(), 0L, 0, true, "", null))
        synchronized(lk) {
            if (hasUrl(url)) throw DuplicateException()
            saveLists(lists() + info)
        }
        return info
    }

    fun editList(id: String, name: String, url: String): ListInfo {
        val old = lists().first { it.id == id }
        val same = normalizeUrl(url) == normalizeUrl(old.url)
        if (!same && hasUrl(url, id)) throw DuplicateException()
        val n = if (same) old.copy(name = name) else fetch(old.copy(name = name, url = url.trim()))
        synchronized(lk) { saveLists(lists().map { if (it.id == id) n else it }) }
        return n
    }

    fun removeList(id: String) {
        synchronized(lk) { saveLists(lists().filter { it.id != id }) }
        File(dir, "list_$id.m3u").delete()
        cache.remove(id); roots.remove(id)
    }

    /** Aggiorna una lista: non lancia errori, ma salva stato verde/rosso con spiegazione. */
    fun refresh(i: ListInfo): ListInfo {
        val n = try {
            fetch(i)
        } catch (e: Exception) {
            i.copy(ok = false, msg = friendlyError(e))
        }
        synchronized(lk) { if (lists().any { it.id == i.id }) saveLists(lists().map { if (it.id == i.id) n else it }) }
        return n
    }

    fun refreshAll(onlyOld: Boolean) {
        val limit = System.currentTimeMillis() - 12 * 3600_000L
        lists().filter { !onlyOld || it.updated < limit }.forEach { refresh(it) }
    }

    private fun fetch(i: ListInfo): ListInfo {
        val tmp = File(dir, "list_${i.id}.tmp")
        val c = openConn(i.url)
        try {
            c.inputStream.use { inp -> tmp.outputStream().use { o -> inp.copyTo(o) } }
        } finally {
            c.disconnect()
        }
        val first = tmp.bufferedReader().use { it.readLine() } ?: ""
        val ch = tmp.useLines { M3u.parse(it) }
        if (ch.isEmpty()) { tmp.delete(); throw EmptyListException() }
        tmp.copyTo(File(dir, "list_${i.id}.m3u"), true)
        tmp.delete()
        cache[i.id] = ch
        roots.remove(i.id)
        val epg = M3u.epgUrl(first)
        val n = i.copy(updated = System.currentTimeMillis(), count = ch.size, ok = true, msg = "", epg = epg)
        if (epg != null) {
            val ids = ch.mapNotNull { it.tvgId }.toSet()
            Thread { runCatching { Epg.refresh(i.id, epg, ids) } }.apply { priority = Thread.MIN_PRIORITY }.start()
        }
        return n
    }

    fun openConn(u: String): HttpURLConnection {
        var cur = u.trim()
        for (n in 0 until 6) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "Lumio/2 (Android TV)")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc == null) throw HttpStatusException(code)
                cur = URL(URL(cur), loc).toString()
                continue
            }
            if (code != 200) { c.disconnect(); throw HttpStatusException(code) }
            return c
        }
        throw Exception("Troppi reindirizzamenti")
    }

    /* ---------- preferiti e "continua a guardare" ---------- */
    private fun Channel.js(): JSONObject = JSONObject().put("n", name).put("u", url).put("g", group)
        .put("l", logo ?: "").put("k", kind.ordinal).put("c", chno ?: -1).put("t", tvgId ?: "")

    private fun chOf(o: JSONObject) = Channel(
        o.getString("n"), o.getString("u"), o.optString("g", "Altri"), o.optString("l", "").ifEmpty { null },
        Kind.values()[o.optInt("k", 0).coerceIn(0, 2)], o.optInt("c", -1).takeIf { it >= 0 },
        o.optString("t", "").ifEmpty { null }
    )

    fun favs(): List<Channel> {
        val a = JSONArray(sp.getString("favs", "[]"))
        return (0 until a.length()).map { chOf(a.getJSONObject(it)) }
    }

    fun toggleFav(c: Channel) {
        val l = favs().toMutableList()
        if (l.any { it.url == c.url }) l.removeAll { it.url == c.url } else l.add(c)
        val a = JSONArray()
        l.forEach { a.put(it.js()) }
        sp.edit().putString("favs", a.toString()).apply()
    }

    fun progress(): List<Prog> {
        val a = JSONArray(sp.getString("prog", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Prog(chOf(o), o.getLong("p"), o.getLong("d"), o.getLong("tm"))
        }.sortedByDescending { it.time }
    }

    private fun saveProg(l: List<Prog>) {
        val a = JSONArray()
        l.take(20).forEach { a.put(it.ch.js().put("p", it.pos).put("d", it.dur).put("tm", it.time)) }
        sp.edit().putString("prog", a.toString()).apply()
    }

    @Synchronized
    fun saveProgress(ch: Channel, pos: Long, dur: Long) {
        if (ch.kind == Kind.LIVE || dur <= 0) return
        val rest = progress().filter { it.ch.url != ch.url }
        if (pos < 20_000) { saveProg(rest); return }
        if (pos > dur * 0.95 || dur - pos < 60_000) { saveProg(rest); return }
        saveProg(listOf(Prog(ch, pos, dur, System.currentTimeMillis())) + rest)
    }

    @Synchronized
    fun removeProgress(url: String) = saveProg(progress().filter { it.ch.url != url })

    fun progOf(url: String): Prog? = progress().firstOrNull { it.ch.url == url }

    /* ---------- aggiornamenti dell'app (release su GitHub) ---------- */
    fun appVersion(c: Context): Int {
        val p = c.packageManager.getPackageInfo(c.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) p.longVersionCode.toInt() else @Suppress("DEPRECATION") p.versionCode
    }

    fun releases(repo: String): List<Rel> {
        val c = openConn("https://api.github.com/repos/$repo/releases?per_page=8")
        val t = try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
        val a = JSONArray(t)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            var apk: String? = null
            val assets = o.optJSONArray("assets")
            if (assets != null) for (k in 0 until assets.length()) {
                val x = assets.getJSONObject(k)
                if (x.optString("name").endsWith(".apk")) apk = x.optString("browser_download_url")
            }
            Rel(o.optString("tag_name"), o.optString("name"), o.optString("published_at").take(10), apk)
        }
    }
}

/** Guida programmi (EPG) salvata in un piccolo database: così non occupa memoria. */
object Epg {
    private lateinit var ctx: Context
    private val helper by lazy {
        object : SQLiteOpenHelper(ctx, "epg.db", null, 1) {
            override fun onCreate(d: SQLiteDatabase) {
                d.execSQL("CREATE TABLE p(l TEXT,c TEXT,s INTEGER,e INTEGER,t TEXT,d TEXT)")
                d.execSQL("CREATE INDEX ix ON p(c,s)")
            }
            override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}
        }
    }

    fun init(c: Context) { ctx = c }

    @Synchronized
    fun query(tvg: String, from: Long, limit: Int): List<Programme> {
        val out = ArrayList<Programme>()
        helper.readableDatabase.rawQuery(
            "SELECT s,e,t,d FROM p WHERE c=? AND e>? ORDER BY s LIMIT ?",
            arrayOf(tvg, from.toString(), limit.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(Programme(c.getLong(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: ""))
        }
        return out
    }

    @Synchronized
    fun clear() { helper.writableDatabase.delete("p", null, null) }

    fun refresh(listId: String, url: String, ids: Set<String>) {
        if (ids.isEmpty()) return
        val conn = Store.openConn(url)
        try {
            var ins: InputStream = BufferedInputStream(conn.inputStream, 65536)
            ins.mark(4)
            val b1 = ins.read()
            val b2 = ins.read()
            ins.reset()
            if (b1 == 0x1f && b2 == 0x8b) ins = GZIPInputStream(ins, 65536)
            val p = Xml.newPullParser()
            p.setInput(ins, null)
            val now = System.currentTimeMillis()
            val lo = now - 2 * 3600_000L
            val hi = now + 36 * 3600_000L
            synchronized(this) {
                val db = helper.writableDatabase
                db.beginTransaction()
                try {
                    db.delete("p", "l=?", arrayOf(listId))
                    val st = db.compileStatement("INSERT INTO p(l,c,s,e,t,d) VALUES(?,?,?,?,?,?)")
                    var ev = p.eventType
                    var ch: String? = null
                    var s = 0L
                    var e = 0L
                    var title = ""
                    var desc = ""
                    var keep = false
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG) {
                            val n = p.name
                            if (n == "programme") {
                                ch = p.getAttributeValue(null, "channel")
                                keep = ch != null && ids.contains(ch)
                                if (keep) {
                                    val a = xmltvTime(p.getAttributeValue(null, "start") ?: "")
                                    val b = xmltvTime(p.getAttributeValue(null, "stop") ?: "")
                                    if (a == null || b == null || b < lo || a > hi) keep = false else { s = a; e = b }
                                }
                                title = ""; desc = ""
                            } else if (n == "title" && keep) {
                                title = p.nextText()
                            } else if (n == "desc" && keep) {
                                desc = p.nextText()
                            }
                        } else if (ev == XmlPullParser.END_TAG && p.name == "programme" && keep) {
                            st.clearBindings()
                            st.bindString(1, listId)
                            st.bindString(2, ch ?: "")
                            st.bindLong(3, s)
                            st.bindLong(4, e)
                            st.bindString(5, title.take(160))
                            st.bindString(6, desc.take(600))
                            st.executeInsert()
                            keep = false
                        }
                        ev = p.next()
                    }
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
            }
        } finally {
            conn.disconnect()
        }
    }
}
