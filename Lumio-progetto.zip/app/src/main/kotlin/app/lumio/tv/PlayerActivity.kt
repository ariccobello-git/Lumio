@file:OptIn(UnstableApi::class)

package app.lumio.tv

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import android.graphics.Color as AColor

class Asp(val name: String, val r: Float)

/** r = 0 nativo, -1 riempi (zoom), -2 stretch, altrimenti proporzione forzata. */
val ASPECTS = listOf(
    Asp("Auto (nativo)", 0f), Asp("Riempi lo schermo (zoom)", -1f), Asp("Stretch a tutto schermo", -2f),
    Asp("4:3", 4f / 3f), Asp("14:9", 14f / 9f), Asp("16:10", 1.6f), Asp("16:9", 16f / 9f),
    Asp("1.85:1 Cinema flat", 1.85f), Asp("2.00:1 Univisium", 2f), Asp("2.20:1 70 mm", 2.2f),
    Asp("2.35:1 Scope", 2.35f), Asp("2.39:1 Scope moderno", 2.39f), Asp("2.55:1 CinemaScope", 2.55f),
    Asp("2.76:1 Ultra Panavision 70", 2.76f), Asp("IMAX 1.43:1", 1.43f), Asp("IMAX digitale 1.90:1", 1.9f),
    Asp("21:9 ultra-wide", 21f / 9f)
)

class PlayerActivity : ComponentActivity() {
    var player by mutableStateOf<ExoPlayer?>(null)
    lateinit var ch: Channel
    var num = 0
    var decoder = 0
    var bufLevel = 1
    private var netCb: ConnectivityManager.NetworkCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Th.apply(Store.theme, Store.customBg)
        val url = intent.getStringExtra("url")
        if (url == null) { finish(); return }
        ch = Channel(
            intent.getStringExtra("name") ?: "", url, intent.getStringExtra("group") ?: "Altri",
            intent.getStringExtra("logo"), Kind.values()[intent.getIntExtra("kind", 0).coerceIn(0, 2)],
            null, intent.getStringExtra("tvg")
        )
        num = intent.getIntExtra("num", 0)
        decoder = Store.decoder
        bufLevel = if (Store.buffer == 0) 1 else Store.buffer
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        player = build()
        start(intent.getLongExtra("resume", 0L))
        registerNet()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { PlayerScreen(this) } }
    }

    fun build(): ExoPlayer {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(12000).setReadTimeoutMs(15000)
        val msf = DefaultMediaSourceFactory(http).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(8))
        val dec = decoder
        val sel = MediaCodecSelector { mime, secure, tunnel ->
            val l = MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunnel)
            when (dec) {
                1 -> l.sortedBy { if (it.softwareOnly) 0 else 1 }
                2 -> l.sortedBy { if (it.hardwareAccelerated) 0 else 1 }
                else -> l
            }
        }
        val rf = DefaultRenderersFactory(this).setMediaCodecSelector(sel).setEnableDecoderFallback(true)
        val lc = (if (bufLevel >= 2)
            DefaultLoadControl.Builder().setBufferDurationsMs(30000, 90000, 3000, 8000).setTargetBufferBytes(48 * 1024 * 1024)
        else
            DefaultLoadControl.Builder().setBufferDurationsMs(15000, 50000, 2500, 5000).setTargetBufferBytes(24 * 1024 * 1024)
                ).build()
        val p = ExoPlayer.Builder(this, rf).setMediaSourceFactory(msf).setLoadControl(lc).build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguage("it").setPreferredTextLanguage("it").build()
        return p
    }

    fun start(resume: Long) {
        val p = player ?: return
        p.setMediaItem(MediaItem.fromUri(ch.url))
        if (resume > 0) p.seekTo(resume)
        p.prepare()
        p.playWhenReady = true
    }

    fun rebuild(dec: Int?, buf: Int?) {
        val old = player
        val pos = old?.currentPosition ?: 0L
        old?.release()
        if (dec != null) decoder = dec
        if (buf != null) bufLevel = buf
        player = build()
        start(if (ch.kind == Kind.LIVE) 0L else pos)
    }

    fun saveProgress() {
        val p = player ?: return
        val d = p.duration
        if (ch.kind != Kind.LIVE && d != C.TIME_UNSET && d > 0) Store.saveProgress(ch, p.currentPosition, d)
    }

    private fun registerNet() {
        val c = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread {
                    val p = player
                    if (p != null && (p.playbackState == Player.STATE_IDLE || p.playerError != null)) p.prepare()
                }
            }
        }
        netCb = cb
        runCatching { c.registerDefaultNetworkCallback(cb) }
    }

    override fun onStop() {
        saveProgress()
        player?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        saveProgress()
        netCb?.let { cb ->
            runCatching { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(cb) }
        }
        player?.release()
        player = null
        super.onDestroy()
    }
}

private fun lbl(g: Tracks.Group, i: Int): String {
    val f = g.getTrackFormat(0)
    val lang = f.language?.let { Locale(it).getDisplayLanguage(Locale("it")).replaceFirstChar { c -> c.uppercase() } }
    return f.label ?: lang ?: "Traccia ${i + 1}"
}

private class QOpt(val g: Tracks.Group, val i: Int, val label: String)

private fun hm(ms: Long): String = SimpleDateFormat("HH:mm", Locale.ITALY).format(Date(ms))

@Composable
fun RoundIcon(kind: Int, onClick: () -> Unit, modifier: Modifier = Modifier, big: Boolean = false, label: String? = null) {
    val sz = if (big) 64.dp else 52.dp
    Tv(onClick, modifier.size(sz), CircleShape, Color(0x55FFFFFF)) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            if (kind == 4) {
                Text("i", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            } else {
                Canvas(Modifier.size(if (big) 28.dp else 18.dp)) {
                    val w = size.width
                    val h = size.height
                    val pth = Path()
                    when (kind) {
                        0 -> { pth.moveTo(w * 0.15f, 0f); pth.lineTo(w, h / 2); pth.lineTo(w * 0.15f, h); pth.close() }
                        2 -> {
                            pth.moveTo(w / 2, 0f); pth.lineTo(0f, h / 2); pth.lineTo(w / 2, h); pth.close()
                            pth.moveTo(w, 0f); pth.lineTo(w / 2, h / 2); pth.lineTo(w, h); pth.close()
                        }
                        3 -> {
                            pth.moveTo(0f, 0f); pth.lineTo(w / 2, h / 2); pth.lineTo(0f, h); pth.close()
                            pth.moveTo(w / 2, 0f); pth.lineTo(w, h / 2); pth.lineTo(w / 2, h); pth.close()
                        }
                    }
                    if (kind == 1) {
                        drawRect(Color.White, Offset(w * 0.12f, 0f), androidx.compose.ui.geometry.Size(w * 0.28f, h))
                        drawRect(Color.White, Offset(w * 0.6f, 0f), androidx.compose.ui.geometry.Size(w * 0.28f, h))
                    } else drawPath(pth, Color.White)
                }
                if (label != null) Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PlayerScreen(a: PlayerActivity) {
    val p = a.player ?: return
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var ui by remember { mutableStateOf(false) }
    var banner by remember { mutableStateOf(true) }
    var menu by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var touch by remember { mutableIntStateOf(0) }
    var aspIdx by remember { mutableIntStateOf(Store.aspect.coerceIn(0, ASPECTS.lastIndex)) }
    var subSize by remember { mutableIntStateOf(Store.subSize) }
    var hc by remember { mutableStateOf(Store.subHc) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var buffering by remember { mutableStateOf(true) }
    var err by remember { mutableStateOf<String?>(null) }
    var attempt by remember { mutableIntStateOf(0) }
    var errEvent by remember { mutableIntStateOf(0) }
    var flash by remember { mutableStateOf<String?>(null) }
    var epg by remember { mutableStateOf(emptyList<Programme>()) }
    val root = remember { FocusRequester() }
    val firstBtn = remember { FocusRequester() }
    val stalls = remember { ArrayList<Long>() }
    val isLive = a.ch.kind == Kind.LIVE || dur <= 0L
    val canSeek = !isLive || p.isCurrentMediaItemSeekable

    DisposableEffect(p) {
        val l = object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) { tick++ }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                val b = state == Player.STATE_BUFFERING
                if (b && !buffering && p.playWhenReady) {
                    val now = System.currentTimeMillis()
                    stalls.add(now)
                    stalls.removeAll { now - it > 60000 }
                    if (stalls.size >= 3 && a.bufLevel < 2) {
                        stalls.clear()
                        Handler(Looper.getMainLooper()).post {
                            Toast.makeText(ctx, "Rallentamenti: allargo il buffer", Toast.LENGTH_SHORT).show()
                            a.rebuild(null, 2)
                        }
                    }
                }
                buffering = b
                if (state == Player.STATE_READY) { err = null; attempt = 0 }
            }
            override fun onPlayerError(error: PlaybackException) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    p.seekToDefaultPosition(); p.prepare(); return
                }
                if (error.errorCode in 4001..4005 && a.decoder != 1) {
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(ctx, "Passo alla decodifica software", Toast.LENGTH_SHORT).show()
                        a.rebuild(1, null)
                    }
                    return
                }
                err = "Connessione persa"
                errEvent++
            }
        }
        p.addListener(l)
        onDispose { p.removeListener(l) }
    }
    // Riconnessione automatica con attese crescenti
    LaunchedEffect(errEvent) {
        if (errEvent > 0) {
            attempt++
            if (attempt > 12) {
                err = "Contenuto non disponibile. Premi OK per riprovare."
            } else {
                err = "Riconnessione… tentativo $attempt"
                delay(minOf(1000L * (1L shl (attempt - 1).coerceAtMost(3)), 8000L))
                p.prepare()
            }
        }
    }
    LaunchedEffect(p) {
        while (true) {
            delay(500)
            val d = p.duration
            dur = if (d == C.TIME_UNSET) 0L else d
            if (ui) pos = p.currentPosition
            playing = p.isPlaying
        }
    }
    LaunchedEffect(p) { while (true) { delay(15000); a.saveProgress() } }
    LaunchedEffect(Unit) { delay(7000); banner = false }
    LaunchedEffect(a.ch.tvgId) {
        val id = a.ch.tvgId
        if (id != null) epg = withContext(Dispatchers.IO) { Epg.query(id, System.currentTimeMillis(), 14) }
    }
    LaunchedEffect(ui, touch, menu, info) {
        if (ui && menu == 0 && !info) { delay(6000); ui = false }
    }
    LaunchedEffect(ui, menu, info) {
        delay(80)
        runCatching {
            if (menu == 0 && !info) { if (ui) firstBtn.requestFocus() else root.requestFocus() }
        }
    }
    LaunchedEffect(flash) { if (flash != null) { delay(900); flash = null } }

    fun toggle() { if (p.isPlaying) p.pause() else p.play() }
    fun seek(d: Long) {
        val t = (p.currentPosition + d).coerceAtLeast(0L)
        val du = p.duration
        p.seekTo(if (du != C.TIME_UNSET) t.coerceAtMost(du) else t)
        pos = p.currentPosition
        flash = (if (d > 0) "+" else "−") + abs(d / 1000) + " s"
    }

    val asp = ASPECTS[aspIdx]
    val now = System.currentTimeMillis()
    val curProg = epg.firstOrNull { it.s <= now && it.e > now }

    Box(
        Modifier.fillMaxSize().background(Color.Black).focusRequester(root)
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                when (e.key) {
                    Key.MediaPlayPause -> { toggle(); true }
                    Key.MediaPlay -> { p.play(); true }
                    Key.MediaPause -> { p.pause(); true }
                    Key.MediaFastForward -> { if (canSeek) seek(30000); true }
                    Key.MediaRewind -> { if (canSeek) seek(-30000); true }
                    Key.DirectionCenter, Key.Enter -> if (!ui) {
                        if (attempt > 12) { attempt = 0; errEvent++ } else { toggle(); ui = true }
                        true
                    } else false
                    Key.DirectionLeft -> if (!ui) { if (canSeek) seek(-10000) else ui = true; true } else false
                    Key.DirectionRight -> if (!ui) { if (canSeek) seek(10000) else ui = true; true } else false
                    Key.DirectionUp, Key.DirectionDown -> if (!ui) { ui = true; true } else false
                    else -> false
                }
            }
            .focusable(),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    setShutterBackgroundColor(AColor.BLACK)
                    player = p
                }
            },
            update = { v ->
                v.player = p
                v.resizeMode = when {
                    asp.r == 0f -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    asp.r == -1f -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    else -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                }
                v.subtitleView?.let { sv ->
                    sv.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * (1f + 0.25f * subSize))
                    if (hc) {
                        sv.setApplyEmbeddedStyles(false)
                        sv.setStyle(CaptionStyleCompat(AColor.YELLOW, AColor.BLACK, AColor.TRANSPARENT, CaptionStyleCompat.EDGE_TYPE_OUTLINE, AColor.BLACK, null))
                    } else {
                        sv.setApplyEmbeddedStyles(true)
                        sv.setStyle(CaptionStyleCompat.DEFAULT)
                    }
                }
            },
            modifier = if (asp.r > 0f) Modifier.aspectRatio(asp.r) else Modifier.fillMaxSize()
        )

        if (err != null) {
            Text(err ?: "", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(12.dp)).background(Color(0xAA000000)).padding(20.dp, 12.dp))
        } else if (buffering) {
            Text("Caricamento…", color = Color.White, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(12.dp)).background(Color(0x88000000)).padding(16.dp, 8.dp))
        }
        if (flash != null) {
            Text(flash ?: "", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 60.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x99000000)).padding(18.dp, 8.dp))
        }

        // Banner in basso per 7 secondi: numero, nome e titolo
        if (banner && !ui && err == null) {
            Row(
                Modifier.align(Alignment.BottomStart).padding(48.dp).clip(RoundedCornerShape(14.dp))
                    .background(Color(0xCC101020)).padding(18.dp, 12.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                if (a.num > 0) Text(a.num.toString(), color = Th.accent, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
                Column {
                    Text(a.ch.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        curProg?.title ?: if (isLive) "In diretta" else (if (a.ch.kind == Kind.MOVIE) "Film" else "Serie TV"),
                        color = Th.muted, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Comandi in stile piattaforme di streaming
        if (ui) {
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent, Color(0xE6000000))))
                    .onPreviewKeyEvent { touch++; false }
            ) {
                Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(48.dp, 28.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(a.ch.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(curProg?.title ?: a.ch.group, color = Th.muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (a.num > 0) Text("CH " + a.num, color = Th.accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Column(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(48.dp, 0.dp, 48.dp, 30.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (!isLive) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(clock(pos), color = Color.White, fontSize = 15.sp)
                            Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x55FFFFFF))) {
                                Box(Modifier.fillMaxWidth((pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f)).fillMaxHeight().background(Th.accent))
                            }
                            Text(clock(dur), color = Color.White, fontSize = 15.sp)
                        }
                    } else {
                        Text("● IN DIRETTA", color = Th.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (epg.isNotEmpty()) RoundIcon(4, { p.pause(); info = true })
                        if (canSeek) RoundIcon(2, { seek(-10000) }, label = "10")
                        RoundIcon(if (playing) 1 else 0, { toggle() }, Modifier.focusRequester(firstBtn), big = true)
                        if (canSeek) RoundIcon(3, { seek(10000) }, label = "10")
                        Spacer(Modifier.weight(1f))
                        val bg = Color(0x44FFFFFF)
                        TvButton("Sottotitoli", { menu = 1 }, w = 112.dp, size = 14f, bg = bg)
                        TvButton("Audio", { menu = 2 }, w = 90.dp, size = 14f, bg = bg)
                        TvButton("Aspetto", { menu = 3 }, w = 100.dp, size = 14f, bg = bg)
                        if (canSeek) TvButton("Velocità", { menu = 4 }, w = 100.dp, size = 14f, bg = bg)
                        TvButton("Qualità", { menu = 5 }, w = 96.dp, size = 14f, bg = bg)
                    }
                }
            }
        }
    }

    // Menu a tendina
    val groups = remember(tick) { p.currentTracks.groups }
    when (menu) {
        1 -> {
            val t = groups.filter { it.type == C.TRACK_TYPE_TEXT }
            val sizes = listOf("Normale", "Un po' più grandi", "Molto grandi")
            val opts = listOf("Disattivati") + t.mapIndexed { i, g -> lbl(g, i) } +
                listOf("Dimensione: " + sizes[subSize], "Alto contrasto: " + (if (hc) "sì" else "no"))
            val sel = t.indexOfFirst { it.isSelected } + 1
            ChoiceDialog("Sottotitoli", opts, sel, { i ->
                val b = p.trackSelectionParameters.buildUpon()
                when {
                    i == 0 -> b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    i <= t.size -> b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setOverrideForType(TrackSelectionOverride(t[i - 1].mediaTrackGroup, 0))
                    i == t.size + 1 -> { subSize = (subSize + 1) % 3; Store.subSize = subSize }
                    else -> { hc = !hc; Store.subHc = hc }
                }
                p.trackSelectionParameters = b.build()
                menu = 0
            }, { menu = 0 })
        }
        2 -> {
            val au = groups.filter { it.type == C.TRACK_TYPE_AUDIO }
            if (au.isEmpty()) { ChoiceDialog("Audio", listOf("Traccia standard"), 0, { menu = 0 }, { menu = 0 }) }
            else ChoiceDialog("Lingua audio", au.mapIndexed { i, g -> lbl(g, i) }, au.indexOfFirst { it.isSelected }, { i ->
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setOverrideForType(TrackSelectionOverride(au[i].mediaTrackGroup, 0)).build()
                menu = 0
            }, { menu = 0 })
        }
        3 -> ChoiceDialog("Aspetto dell'immagine", ASPECTS.map { it.name }, aspIdx, { i ->
            aspIdx = i; Store.aspect = i; menu = 0
        }, { menu = 0 })
        4 -> {
            val sp = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
            ChoiceDialog("Velocità", sp.map { if (it == 1f) "Normale" else "${it}x" }, sp.indexOf(p.playbackParameters.speed), { i ->
                p.setPlaybackSpeed(sp[i]); menu = 0
            }, { menu = 0 })
        }
        5 -> {
            val q = ArrayList<QOpt>()
            for (g in groups) if (g.type == C.TRACK_TYPE_VIDEO) for (i in 0 until g.length) {
                val f = g.getTrackFormat(i)
                if (g.isTrackSupported(i) && f.height > 0) q.add(QOpt(g, i, f.height.toString() + "p"))
            }
            val uniq = q.distinctBy { it.label }.sortedByDescending { it.label.dropLast(1).toIntOrNull() ?: 0 }
            if (uniq.size < 2) ChoiceDialog("Qualità", listOf("Automatica (unica disponibile)"), 0, { menu = 0 }, { menu = 0 })
            else ChoiceDialog("Qualità", listOf("Automatica") + uniq.map { it.label }, 0, { i ->
                val b = p.trackSelectionParameters.buildUpon()
                if (i == 0) b.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                else b.setOverrideForType(TrackSelectionOverride(uniq[i - 1].g.mediaTrackGroup, uniq[i - 1].i))
                p.trackSelectionParameters = b.build()
                menu = 0
            }, { menu = 0 })
        }
    }

    // Info: video in pausa, testo al centro; alla chiusura resta in pausa
    if (info) {
        LinesDialog("Guida programmi · " + a.ch.name, epg.map { Triple(hm(it.s) + "–" + hm(it.e), it.title, it.desc) }) { info = false }
    }

    // Indietro: prima chiude i comandi, poi esce dal player
    BackHandler { if (ui) ui = false else a.finish() }
}
