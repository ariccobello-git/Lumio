@file:OptIn(UnstableApi::class)

package app.lumio.tv

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        val url = intent.getStringExtra("url")
        if (url == null) { finish(); return }
        val ch = Channel(
            intent.getStringExtra("name") ?: "", url,
            intent.getStringExtra("group") ?: "Altri", intent.getStringExtra("logo")
        )
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val p = ExoPlayer.Builder(this).setMediaSourceFactory(DefaultMediaSourceFactory(http)).build()
        p.setMediaItem(MediaItem.fromUri(url))
        p.prepare()
        p.playWhenReady = true
        player = p
        setContent { PlayerScreen(p, ch) { finish() } }
    }

    override fun onStop() {
        player?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

private val FORMATS = listOf(
    "Auto" to 0f, "Riempi" to -1f, "Stretch" to -2f, "4:3" to 4f / 3f,
    "16:9" to 16f / 9f, "21:9" to 21f / 9f, "1.85:1" to 1.85f, "2.35:1" to 2.35f
)

private fun lbl(g: Tracks.Group, i: Int): String {
    val f = g.getTrackFormat(0)
    return f.label ?: f.language?.let { Locale(it).displayLanguage } ?: "Traccia ${i + 1}"
}

private fun cycle(p: Player, type: Int, canDisable: Boolean) {
    val gs = p.currentTracks.groups.filter { it.type == type }
    if (gs.isEmpty()) return
    val n = gs.indexOfFirst { it.isSelected } + 1
    val b = p.trackSelectionParameters.buildUpon()
    if (n >= gs.size) {
        if (canDisable) b.setTrackTypeDisabled(type, true) else b.setOverrideForType(TrackSelectionOverride(gs[0].mediaTrackGroup, 0))
    } else {
        b.setTrackTypeDisabled(type, false).setOverrideForType(TrackSelectionOverride(gs[n].mediaTrackGroup, 0))
    }
    p.trackSelectionParameters = b.build()
}

@Composable
fun PlayerScreen(p: ExoPlayer, ch: Channel, onClose: () -> Unit) {
    var ui by remember { mutableStateOf(true) }
    var mode by remember { mutableStateOf(0) }
    var tick by remember { mutableStateOf(0) }
    var touch by remember { mutableStateOf(0) }
    var fav by remember { mutableStateOf(Store.isFav(ch.url)) }
    var err by remember { mutableStateOf<String?>(null) }
    var wait by remember { mutableStateOf(true) }
    val root = remember { FocusRequester() }
    val reqs = remember { List(FORMATS.size) { FocusRequester() } }

    DisposableEffect(p) {
        val l = object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) { tick++ }
            override fun onPlayerError(error: PlaybackException) { err = "Impossibile riprodurre questo canale" }
            override fun onPlaybackStateChanged(state: Int) {
                wait = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) err = null
            }
        }
        p.addListener(l)
        onDispose { p.removeListener(l) }
    }
    LaunchedEffect(ui) {
        delay(80)
        runCatching { if (ui) reqs[mode].requestFocus() else root.requestFocus() }
    }
    LaunchedEffect(ui, touch) {
        if (ui) { delay(10000); ui = false }
    }
    BackHandler { if (ui) ui = false else onClose() }

    val subs = remember(tick) { p.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT } }
    val auds = remember(tick) { p.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO } }
    val subTxt = if (subs.isEmpty()) "Sottotitoli: non disponibili" else {
        val i = subs.indexOfFirst { it.isSelected }
        "Sottotitoli: " + (if (i < 0) "spenti" else lbl(subs[i], i))
    }
    val audTxt = if (auds.isEmpty()) "Audio: standard" else {
        val i = auds.indexOfFirst { it.isSelected }.coerceAtLeast(0)
        "Audio: " + lbl(auds[i], i)
    }
    val r = FORMATS[mode].second

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(root)
            .onKeyEvent { if (!ui) { ui = true; true } else false }
            .focusable(),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    player = p
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = {
                it.resizeMode = when {
                    r == 0f -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    r == -1f -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    else -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                }
            },
            modifier = if (r > 0f) Modifier.aspectRatio(r) else Modifier.fillMaxSize()
        )
        if (err != null) {
            Text(err!!, color = Color.White, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
        } else if (wait) {
            Text("Caricamento…", color = Color.White, fontSize = 18.sp, modifier = Modifier.align(Alignment.Center))
        }
        if (ui) {
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent, Color(0xE6000000))))
                    .onPreviewKeyEvent { touch++; false }
            ) {
                Text(
                    ch.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(40.dp)
                )
                Column(Modifier.align(Alignment.BottomStart).padding(40.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Formato video", color = Color(0xFFDFE0FF), fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FORMATS.forEachIndexed { i, f ->
                            TvButton(f.first, { mode = i }, Modifier.focusRequester(reqs[i]), selected = i == mode)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TvButton(subTxt, { cycle(p, C.TRACK_TYPE_TEXT, true) })
                        TvButton(audTxt, { cycle(p, C.TRACK_TYPE_AUDIO, false) })
                        TvButton(if (fav) "♥ Preferito" else "♡ Preferito", { Store.toggleFav(ch); fav = Store.isFav(ch.url) })
                        TvButton("Chiudi", onClose)
                    }
                }
            }
        }
    }
}
