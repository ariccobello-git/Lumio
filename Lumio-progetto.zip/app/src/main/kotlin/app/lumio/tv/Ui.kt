@file:OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)

package app.lumio.tv

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import kotlin.math.abs

val BG = Color(0xFF0E1021)
val Surface = Color(0xFF181B33)
val Surface2 = Color(0xFF232748)
val Accent = Color(0xFFFF3D7F)
val Violet = Color(0xFF6C5CFF)
val Muted = Color(0xFF9AA0C8)

@Composable
fun Tv(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(10.dp),
    bg: Color = Surface2,
    content: @Composable BoxScope.() -> Unit
) {
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.06f else 1f, label = "focus")
    Box(
        modifier
            .scale(s)
            .onFocusChanged { f = it.isFocused }
            .clip(shape)
            .background(bg)
            .then(if (f) Modifier.border(3.dp, Color.White, shape) else Modifier)
            .clickable(onClick = onClick),
        content = content
    )
}

@Composable
fun TvButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    selected: Boolean = false,
    bg: Color? = null
) {
    Tv(onClick, modifier, RoundedCornerShape(24.dp), bg ?: (if (primary) Accent else if (selected) Violet else Surface2)) {
        Text(
            text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
        )
    }
}

// ---- utilità per modificare il testo nel punto del cursore ----
fun TextFieldValue.ins(s: String): TextFieldValue {
    val a = selection.min.coerceIn(0, text.length)
    val b = selection.max.coerceIn(0, text.length)
    return TextFieldValue(text.replaceRange(a, b, s), TextRange(a + s.length))
}

fun TextFieldValue.del(): TextFieldValue {
    val a = selection.min.coerceIn(0, text.length)
    val b = selection.max.coerceIn(0, text.length)
    if (a != b) return TextFieldValue(text.removeRange(a, b), TextRange(a))
    if (a == 0) return this
    return TextFieldValue(text.removeRange(a - 1, a), TextRange(a - 1))
}

fun TextFieldValue.mv(d: Int): TextFieldValue {
    val p = (selection.end + d).coerceIn(0, text.length)
    return TextFieldValue(text, TextRange(p))
}

private class CursorVT(val pos: Int) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val p = pos.coerceIn(0, text.length)
        val t = AnnotatedString(text.text.substring(0, p) + "|" + text.text.substring(p))
        return TransformedText(t, object : OffsetMapping {
            override fun originalToTransformed(offset: Int) = if (offset >= p) offset + 1 else offset
            override fun transformedToOriginal(offset: Int) = if (offset > p) offset - 1 else offset
        })
    }
}

/** Campo di testo vero: accetta la tastiera di sistema (anche dall'app Google TV sul telefono) e la tastiera di Lumio. */
@Composable
fun TvField(
    label: String,
    value: TextFieldValue,
    onChange: (TextFieldValue) -> Unit,
    active: Boolean,
    modifier: Modifier = Modifier,
    singleLine: Boolean = false,
    onActive: () -> Unit = {},
    onDone: () -> Unit = {}
) {
    val fm = LocalFocusManager.current
    val kc = LocalSoftwareKeyboardController.current
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier.clip(shape).background(Surface)
            .then(if (focused) Modifier.border(3.dp, Color.White, shape) else Modifier)
            .onFocusChanged {
                focused = it.hasFocus
                if (it.hasFocus) onActive() else kc?.hide()
            }
            .padding(14.dp)
    ) {
        Text(label, color = if (active || focused) Accent else Muted, fontSize = 13.sp)
        BasicTextField(
            value = value,
            onValueChange = { if (it.text.contains('\n')) onDone() else onChange(it) },
            singleLine = singleLine,
            textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
            cursorBrush = SolidColor(Accent),
            visualTransformation = if (active && !focused) CursorVT(value.selection.end) else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done, keyboardType = KeyboardType.Text),
            keyboardActions = KeyboardActions(onDone = { kc?.hide(); onDone() }),
            modifier = Modifier.fillMaxWidth().onPreviewKeyEvent { e ->
                if (e.type == KeyEventType.KeyDown) {
                    when (e.key) {
                        Key.DirectionLeft -> { fm.moveFocus(FocusDirection.Left); true }
                        Key.DirectionRight -> { fm.moveFocus(FocusDirection.Right); true }
                        Key.DirectionUp -> { fm.moveFocus(FocusDirection.Up); true }
                        Key.DirectionDown -> { fm.moveFocus(FocusDirection.Down); true }
                        Key.DirectionCenter, Key.Enter -> { kc?.show(); true }
                        else -> false
                    }
                } else false
            }
        )
    }
}

private class KD(val label: String, val w: Dp, val act: () -> Unit)

@Composable
fun Keyboard(
    onKey: (String) -> Unit, onDel: () -> Unit, onClear: () -> Unit,
    onLeft: () -> Unit, onRight: () -> Unit, onExit: () -> Unit
) {
    var sym by remember { mutableStateOf(false) }
    var caps by remember { mutableStateOf(false) }
    val reqs = remember { List(5) { List(12) { FocusRequester() } } }
    val src = if (sym) listOf("!?#%&*()+=", "[]{}<>|\\^~", "/:;'\"`,€\$@", "._-,°§")
    else listOf("1234567890", "qwertyuiop", "asdfghjkl-", "zxcvbnm._@")
    val rows: List<List<KD>> = src.map { r ->
        r.map { ch ->
            val s = if (caps) ch.uppercaseChar().toString() else ch.toString()
            KD(s, 46.dp) { onKey(s) }
        }
    } + listOf(
        listOf(
            KD("Aa", 46.dp) { caps = !caps },
            KD(if (sym) "ABC" else "#+=", 56.dp) { sym = !sym },
            KD("Spazio", 100.dp) { onKey(" ") },
            KD("◀", 46.dp) { onLeft() },
            KD("▶", 46.dp) { onRight() },
            KD("⌫", 56.dp) { onDel() },
            KD("Canc", 56.dp) { onClear() },
            KD("Fine", 58.dp) { onExit() }
        )
    )
    val centers = rows.map { r ->
        var x = 0f
        r.map { k -> val c = x + k.w.value / 2f; x += k.w.value + 6f; c }
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.forEachIndexed { ri, r ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                r.forEachIndexed { ci, k ->
                    Tv(
                        k.act,
                        Modifier.size(k.w, 44.dp).focusRequester(reqs[ri][ci]).onPreviewKeyEvent { e ->
                            if (e.type != KeyEventType.KeyDown) false
                            else when (e.key) {
                                Key.DirectionLeft -> { reqs[ri][(ci - 1 + r.size) % r.size].requestFocus(); true }
                                Key.DirectionRight -> { reqs[ri][(ci + 1) % r.size].requestFocus(); true }
                                Key.DirectionUp, Key.DirectionDown -> {
                                    val nr = (ri + (if (e.key == Key.DirectionDown) 1 else -1) + rows.size) % rows.size
                                    val x = centers[ri][ci]
                                    val nc = centers[nr].indices.minByOrNull { abs(centers[nr][it] - x) } ?: 0
                                    reqs[nr][nc].requestFocus()
                                    true
                                }
                                else -> false
                            }
                        }
                    ) {
                        Text(k.label, color = Color.White, fontSize = 16.sp, modifier = Modifier.align(Alignment.Center))
                    }
                }
            }
        }
    }
}
