@file:OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)

package app.lumio.tv

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

/* ---------- Colori e sfondi (cambiabili dalle Impostazioni) ---------- */
class Preset(val name: String, val bg: Long, val s1: Long, val s2: Long, val accent: Long, val violet: Long)

object Th {
    var bg by mutableStateOf(Color(0xFF0E1021))
    var surface by mutableStateOf(Color(0xFF181B33))
    var surface2 by mutableStateOf(Color(0xFF232748))
    var accent by mutableStateOf(Color(0xFFFF3D7F))
    var violet by mutableStateOf(Color(0xFF6C5CFF))
    val muted = Color(0xFFB4B9DE)
    val ok = Color(0xFF3DDC84)
    val bad = Color(0xFFFF5A5F)

    val presets = listOf(
        Preset("Notte viola", 0xFF0E1021, 0xFF181B33, 0xFF232748, 0xFFFF3D7F, 0xFF6C5CFF),
        Preset("Cinema bordeaux", 0xFF1A0C12, 0xFF281520, 0xFF3A1E2E, 0xFFFF8A3D, 0xFFC2336B),
        Preset("Oceano", 0xFF08161F, 0xFF102430, 0xFF173544, 0xFF2EC4B6, 0xFF3A86FF),
        Preset("Bosco", 0xFF0B1A14, 0xFF13291F, 0xFF1C3A2C, 0xFFF2B84B, 0xFF3FA66B)
    )
    val swatches = listOf(
        "Grafite" to 0xFF121212, "Blu profondo" to 0xFF0A1030, "Prugna" to 0xFF1D0F24,
        "Petrolio" to 0xFF06222B, "Ambra scuro" to 0xFF21150A, "Verde scuro" to 0xFF0C1F12,
        "Rosso scuro" to 0xFF240D0D, "Indaco" to 0xFF12123A
    )

    private fun mix(c: Color, w: Float) = Color(
        c.red + (1f - c.red) * w, c.green + (1f - c.green) * w, c.blue + (1f - c.blue) * w
    )

    fun apply(preset: Int, custom: Long) {
        val p = presets[preset.coerceIn(0, presets.lastIndex)]
        accent = Color(p.accent)
        violet = Color(p.violet)
        if (custom != 0L) {
            val b = Color(custom)
            bg = b; surface = mix(b, 0.07f); surface2 = mix(b, 0.14f)
        } else {
            bg = Color(p.bg); surface = Color(p.s1); surface2 = Color(p.s2)
        }
    }
}

/* ---------- Componenti base ---------- */
@Composable
fun Tv(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(10.dp),
    bg: Color = Th.surface2,
    content: @Composable BoxScope.() -> Unit
) {
    var f by remember { mutableStateOf(false) }
    Box(
        modifier
            .onFocusChanged { f = it.isFocused }
            .clip(shape)
            .background(bg)
            .then(if (f) Modifier.border(3.dp, Color.White, shape) else Modifier)
            .clickable(onClick = onClick),
        content = content
    )
}

/** Testo su una riga sola: se non entra, si rimpicciolisce da solo. */
@Composable
fun FitText(
    text: String, color: Color, maxSp: Float, modifier: Modifier = Modifier,
    bold: Boolean = false, align: TextAlign = TextAlign.Center
) {
    var sz by remember(text, maxSp) { mutableStateOf(maxSp) }
    Text(
        text, color = color, fontSize = sz.sp, maxLines = 1, softWrap = false,
        overflow = TextOverflow.Clip, textAlign = align,
        fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
        modifier = modifier,
        onTextLayout = { if (it.didOverflowWidth && sz > 9f) sz = (sz * 0.92f).coerceAtLeast(9f) }
    )
}

@Composable
fun TvButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    w: Dp? = 160.dp, h: Dp = 44.dp, primary: Boolean = false, selected: Boolean = false,
    bg: Color? = null, size: Float = 16f
) {
    val m = (if (w != null) modifier.width(w) else modifier).height(h)
    Tv(onClick, m, RoundedCornerShape(22.dp), bg ?: (if (primary) Th.accent else if (selected) Th.violet else Th.surface2)) {
        FitText(text, Color.White, size, Modifier.align(Alignment.Center).padding(horizontal = 12.dp), true)
    }
}

@Composable
fun Dot(ok: Boolean) {
    Box(Modifier.size(12.dp).clip(CircleShape).background(if (ok) Th.ok else Th.bad))
}

/** Campo di testo vero: OK sul telecomando apre la tastiera di sistema (anche dall'app Google TV). */
@Composable
fun TvField(
    label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier,
    singleLine: Boolean = false, onDone: () -> Unit = {}
) {
    val fm = LocalFocusManager.current
    val kc = LocalSoftwareKeyboardController.current
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier.clip(shape).background(Th.surface)
            .then(if (focused) Modifier.border(3.dp, Color.White, shape) else Modifier)
            .onFocusChanged {
                focused = it.hasFocus
                if (!it.hasFocus) kc?.hide()
            }
            .padding(14.dp)
    ) {
        Text(label, color = if (focused) Th.accent else Th.muted, fontSize = 13.sp)
        BasicTextField(
            value = value,
            onValueChange = { if (it.contains('\n')) onDone() else onChange(it) },
            singleLine = singleLine,
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
            cursorBrush = SolidColor(Th.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done, keyboardType = KeyboardType.Text),
            keyboardActions = KeyboardActions(onDone = { kc?.hide(); onDone() }),
            modifier = Modifier.fillMaxWidth().onPreviewKeyEvent { e ->
                if (e.type == KeyEventType.KeyDown) {
                    when (e.key) {
                        Key.DirectionLeft -> { fm.moveFocus(FocusDirection.Left); true }
                        Key.DirectionRight -> { fm.moveFocus(FocusDirection.Right); true }
                        Key.DirectionUp -> { fm.moveFocus(FocusDirection.Up); true }
                        Key.DirectionDown -> { fm.moveFocus(FocusDirection.Down); true }
                        Key.DirectionCenter, Key.Enter -> { kc?.show(); true }
                        else -> false
                    }
                } else false
            }
        )
    }
}

/* ---------- Finestre ---------- */
@Composable
fun ChoiceDialog(title: String, options: List<String>, selected: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) { delay(60); runCatching { fr.requestFocus() } }
        Column(
            Modifier.width(480.dp).heightIn(max = 430.dp).clip(RoundedCornerShape(16.dp))
                .background(Th.surface).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(options) { i, o ->
                    val m = (if (i == selected.coerceAtLeast(0)) Modifier.focusRequester(fr) else Modifier)
                        .fillMaxWidth().height(46.dp)
                    Tv({ onPick(i) }, m) {
                        Row(Modifier.align(Alignment.CenterStart).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (i == selected) "✓ " else "    ", color = Th.accent, fontSize = 16.sp)
                            FitText(o, Color.White, 16f, Modifier.width(380.dp), false, TextAlign.Start)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String, msg: String, yes: String, onYes: () -> Unit, onDismiss: () -> Unit,
    no: String = "Annulla"
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) { delay(60); runCatching { fr.requestFocus() } }
        Column(
            Modifier.width(560.dp).clip(RoundedCornerShape(16.dp)).background(Th.surface).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(msg, color = Th.muted, fontSize = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TvButton(no, onDismiss, Modifier.weight(1f).focusRequester(fr), w = null)
                TvButton(yes, onYes, Modifier.weight(1f), w = null, primary = true)
            }
        }
    }
}

/** Testo lungo scorrevole con le frecce del telecomando (o dell'app Google TV). */
@Composable
fun LinesDialog(title: String, lines: List<Triple<String, String, String>>, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) { delay(60); runCatching { fr.requestFocus() } }
        Column(
            Modifier.width(760.dp).heightIn(max = 440.dp).clip(RoundedCornerShape(16.dp))
                .background(Th.surface).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(lines) { i, l ->
                    Tv({}, (if (i == 0) Modifier.focusRequester(fr) else Modifier).fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            if (l.first.isNotEmpty()) Text(l.first, color = Th.accent, fontSize = 14.sp)
                            Text(l.second, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            if (l.third.isNotEmpty()) Text(l.third, color = Th.muted, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
    }
}
