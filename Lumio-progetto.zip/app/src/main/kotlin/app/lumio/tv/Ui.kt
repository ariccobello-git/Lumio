package app.lumio.tv

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val BG = Color(0xFF0E1021)
val Surface = Color(0xFF181B33)
val Surface2 = Color(0xFF232748)
val Accent = Color(0xFFFF3D7F)
val Violet = Color(0xFF6C5CFF)
val Muted = Color(0xFF9AA0C8)

@Composable
fun Tv(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(10.dp),
    bg: Color = Surface2,
    content: @Composable BoxScope.() -> Unit
) {
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.06f else 1f, label = "focus")
    Box(
        modifier
            .scale(s)
            .onFocusChanged { f = it.isFocused }
            .clip(shape)
            .background(bg)
            .then(if (f) Modifier.border(3.dp, Color.White, shape) else Modifier)
            .clickable(onClick = onClick),
        content = content
    )
}

@Composable
fun TvButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    selected: Boolean = false,
    bg: Color? = null
) {
    Tv(onClick, modifier, RoundedCornerShape(24.dp), bg ?: (if (primary) Accent else if (selected) Violet else Surface2)) {
        Text(
            text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
        )
    }
}

@Composable
fun Kb(t: String, w: Dp, onClick: () -> Unit) {
    Tv(onClick, Modifier.size(w, 44.dp)) {
        Text(t, color = Color.White, fontSize = 16.sp, modifier = Modifier.align(Alignment.Center))
    }
}

@Composable
fun Keyboard(onKey: (String) -> Unit, onDel: () -> Unit, onClear: () -> Unit) {
    var sym by remember { mutableStateOf(false) }
    var caps by remember { mutableStateOf(false) }
    val rows = if (sym) listOf("!?#%&*()+", "=/:;'\"\$€<>", "[]{}|\\^~`,@")
    else listOf("1234567890", "qwertyuiop", "asdfghjkl-", "zxcvbnm._@")
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                r.forEach { ch ->
                    val s = if (caps) ch.uppercaseChar().toString() else ch.toString()
                    Kb(s, 46.dp) { onKey(s) }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Kb("Aa", 46.dp) { caps = !caps }
            Kb(if (sym) "ABC" else "#+=", 60.dp) { sym = !sym }
            Kb("Spazio", 160.dp) { onKey(" ") }
            Kb("⌫", 60.dp) { onDel() }
            Kb("Canc", 60.dp) { onClear() }
        }
    }
}
