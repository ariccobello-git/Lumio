package app.lumio.tv

import java.net.ConnectException
import java.net.MalformedURLException
import java.net.SocketTimeoutException
import java.net.URI
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.SSLException

/* ====== Logica pura (nessuna dipendenza Android): è la parte che ho potuto provare con test automatici ====== */

enum class Kind { LIVE, MOVIE, SERIES }

data class Channel(
    val name: String,
    val url: String,
    val group: String,
    val logo: String?,
    val kind: Kind = Kind.LIVE,
    val chno: Int? = null,      // numero identificativo: usato solo per ordinare e per il banner del player
    val tvgId: String? = null   // id per la guida EPG
)

class HttpStatusException(val code: Int) : Exception("HTTP $code")
class EmptyListException : Exception("lista vuota")

object M3u {
    private val attr = Regex("""([\w-]+)="([^"]*)"""")
    private val seRe = Regex("""[sS](\d{1,2})[ ._-]*[eE](\d{1,3})""")
    private val filmGroup = Regex("""\b(film|movies?|vod)\b""")
    private val serieGroup = Regex("""\b(serie|series|tv shows?)\b""")
    private val fileExt = listOf(".mp4", ".mkv", ".avi", ".mov", ".m4v")

    fun epgUrl(firstLine: String): String? {
        val l = firstLine.trimStart('\uFEFF').trim()
        if (!l.startsWith("#EXTM3U")) return null
        val a = attr.findAll(l).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
        return (a["url-tvg"] ?: a["x-tvg-url"])?.split(',')?.map { it.trim() }?.firstOrNull { it.isNotEmpty() }
    }

    fun classify(url: String, group: String, name: String): Kind {
        val u = url.lowercase()
        val g = group.lowercase()
        if ("/movie/" in u) return Kind.MOVIE
        if ("/series/" in u) return Kind.SERIES
        if (seRe.containsMatchIn(name)) return Kind.SERIES
        val path = u.substringBefore('?')
        if (fileExt.any { path.endsWith(it) }) return Kind.MOVIE
        if (serieGroup.containsMatchIn(g)) return Kind.SERIES
        if (filmGroup.containsMatchIn(g)) return Kind.MOVIE
        return Kind.LIVE
    }

    fun parse(lines: Sequence<String>): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var group = "Altri"
        var logo: String? = null
        var chno: Int? = null
        var tvg: String? = null
        for (raw in lines) {
            val l = raw.trimStart('\uFEFF').trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#EXTINF")) {
                val a = attr.findAll(l).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                group = a["group-title"]?.takeIf { it.isNotBlank() } ?: "Altri"
                logo = a["tvg-logo"]?.takeIf { it.isNotBlank() }
                chno = (a["tvg-chno"] ?: a["channel-number"])?.trim()?.toIntOrNull()
                tvg = a["tvg-id"]?.takeIf { it.isNotBlank() }
                val after = titleAfterHeader(l)
                name = after.ifEmpty { a["tvg-name"] ?: "Senza nome" }
            } else if (!l.startsWith("#")) {
                val n = name ?: l
                out.add(Channel(n, l, group, logo, M3u.classify(l, group, n), chno, tvg))
                name = null; group = "Altri"; logo = null; chno = null; tvg = null
            }
        }
        return out
    }
}

/** Il titolo inizia dopo la prima virgola fuori dalle virgolette: così i nomi con la virgola restano interi. */
fun titleAfterHeader(l: String): String {
    var q = false
    for (i in l.indices) {
        val c = l[i]
        if (c == '"') q = !q
        else if (c == ',' && !q) return l.substring(i + 1).trim()
    }
    return ""
}

/** Due indirizzi sono "uguali" anche se cambiano maiuscole nel dominio, porta di default o / finale. */
fun normalizeUrl(u: String): String {
    val t = u.trim()
    return try {
        val x = URI(t)
        val sc = (x.scheme ?: "").lowercase()
        val h = (x.host ?: "").lowercase()
        val p = (x.rawPath ?: "").trimEnd('/')
        val port = if (x.port == -1 || (sc == "http" && x.port == 80) || (sc == "https" && x.port == 443)) "" else ":${x.port}"
        sc + "://" + h + port + p + (if (x.rawQuery != null) "?" + x.rawQuery else "")
    } catch (e: Exception) {
        t.lowercase().trimEnd('/')
    }
}

fun friendlyError(e: Throwable): String = when (e) {
    is HttpStatusException -> when (e.code) {
        401, 403 -> "Accesso negato dal server (lista scaduta, bloccata o credenziali errate)"
        404 -> "Lista non trovata: controlla l'indirizzo"
        in 500..599 -> "Il server della lista ha un problema (errore ${e.code})"
        else -> "Il server ha risposto con errore ${e.code}"
    }
    is UnknownHostException -> "Indirizzo non raggiungibile: controlla internet o come è scritto"
    is SocketTimeoutException -> "Il server non risponde (tempo scaduto)"
    is ConnectException -> "Impossibile collegarsi al server"
    is SSLException -> "Problema di sicurezza HTTPS con il server"
    is MalformedURLException -> "Indirizzo non valido"
    is EmptyListException -> "File scaricato ma senza canali validi"
    else -> e.message?.take(80) ?: "Errore sconosciuto"
}

/* ---------- Albero di navigazione a livelli (drill-through) ---------- */

sealed class Node { abstract val title: String }
class Folder(
    override val title: String,
    val count: Int,
    val sortable: Boolean = true,
    val kids: () -> List<Node>
) : Node()
class Leaf(val ch: Channel) : Node() {
    override val title: String get() = ch.name
}

data class Ep(val title: String, val season: Int, val ep: Int)

private val seRe2 = Regex("""[sS](\d{1,2})[ ._-]*[eE](\d{1,3})""")

fun seriesInfo(name: String): Ep? {
    val m = seRe2.find(name) ?: return null
    val t = name.substring(0, m.range.first).trim().trimEnd('-', '.', '_', ':', '|', ' ').trim()
    return Ep(t.ifEmpty { name }, m.groupValues[1].toInt(), m.groupValues[2].toInt())
}

fun buildRoot(all: List<Channel>): List<Node> {
    val out = ArrayList<Node>()
    fun sec(name: String, k: Kind) {
        val l = all.filter { it.kind == k }
        if (l.isNotEmpty()) out.add(Folder(name, l.size) { categories(l, k == Kind.SERIES) })
    }
    sec("Live TV", Kind.LIVE)
    sec("Film", Kind.MOVIE)
    sec("Serie TV", Kind.SERIES)
    if (out.size == 1) return (out[0] as Folder).kids()
    return out
}

fun categories(l: List<Channel>, series: Boolean): List<Node> {
    val g = l.groupBy { it.group }
    if (g.size == 1) {
        val only = g.values.first()
        return if (series) seriesNodes(only) else leafNodes(only)
    }
    return g.map { (name, cs) -> Folder(name, cs.size) { if (series) seriesNodes(cs) else leafNodes(cs) } }
}

fun leafNodes(cs: List<Channel>): List<Node> {
    if (cs.size <= 600) return cs.map { Leaf(it) }
    val by = cs.groupBy { c -> c.name.trim().firstOrNull()?.let { if (it.isLetter()) it.uppercaseChar().toString() else "#" } ?: "#" }
    return by.toSortedMap().map { (k, v) -> Folder(k, v.size) { v.map { Leaf(it) } } }
}

fun seriesNodes(cs: List<Channel>): List<Node> {
    val out = ArrayList<Node>()
    val groups = LinkedHashMap<String, MutableList<Pair<Ep, Channel>>>()
    for (c in cs) {
        val e = seriesInfo(c.name)
        if (e == null) out.add(Leaf(c)) else groups.getOrPut(e.title) { ArrayList() }.add(e to c)
    }
    for ((title, eps) in groups) {
        val seasons = eps.groupBy { it.first.season }.toSortedMap()
        if (seasons.size == 1) {
            val sorted = eps.sortedBy { it.first.ep }
            out.add(Folder(title, eps.size, false) { sorted.map { Leaf(it.second) } })
        } else {
            out.add(Folder(title, eps.size, false) {
                seasons.map { (s, l) ->
                    val sorted = l.sortedBy { it.first.ep }
                    Folder("Stagione $s", l.size, false) { sorted.map { Leaf(it.second) } }
                }
            })
        }
    }
    return out
}

enum class Sort(val label: String) {
    LIST("Ordine della lista"), AZ("A-Z"), ZA("Z-A"),
    NEW("Ultimi inseriti"), NUM_UP("Numero crescente"), NUM_DOWN("Numero decrescente")
}

fun numOf(n: Node): Int? = (n as? Leaf)?.ch?.chno

fun hasNumbers(nodes: List<Node>): Boolean = nodes.any { numOf(it) != null }

fun sortNodes(n: List<Node>, s: Sort): List<Node> = when (s) {
    Sort.LIST -> n
    Sort.AZ -> n.sortedBy { it.title.lowercase() }
    Sort.ZA -> n.sortedByDescending { it.title.lowercase() }
    Sort.NEW -> n.asReversed()
    Sort.NUM_UP -> n.sortedBy { numOf(it) ?: Int.MAX_VALUE }
    Sort.NUM_DOWN -> n.sortedByDescending { numOf(it) ?: -1 }
}

/* ---------- Guida (EPG) e orari ---------- */

fun xmltvTime(s: String): Long? {
    val t = s.trim()
    return try {
        when {
            Regex("""\d{14} ?[+-]\d{4}""").matches(t) -> {
                val f = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
                f.parse(t.replace(Regex("""(\d{14}) ?([+-]\d{4})"""), "$1 $2"))?.time
            }
            Regex("""\d{14}""").matches(t) -> {
                val f = SimpleDateFormat("yyyyMMddHHmmss", Locale.US)
                f.timeZone = TimeZone.getTimeZone("UTC")
                f.parse(t)?.time
            }
            else -> null
        }
    } catch (e: Exception) {
        null
    }
}

fun clock(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val x = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%d:%02d".format(m, x)
}
